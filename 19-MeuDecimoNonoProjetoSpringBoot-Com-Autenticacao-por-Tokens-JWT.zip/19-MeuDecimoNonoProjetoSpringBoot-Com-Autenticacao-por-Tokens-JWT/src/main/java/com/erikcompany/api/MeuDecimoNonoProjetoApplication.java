package com.erikcompany.api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.erikcompany.api.security.entities.Usuario;
import com.erikcompany.api.security.enums.PerfilEnum;
import com.erikcompany.api.security.repositories.UsuarioRepository;
import com.erikcompany.api.utils.SenhaUtils;


//Classe principal que de fato executa o projeto.


@SpringBootApplication //Anotacao do Spring Boot que faz tudo acontecer. Inicializa o Spring Boot, componentes, entre outras coisas.
public class MeuDecimoNonoProjetoApplication {
	
	
	
	
	@Autowired  //Anotacao do Spring que injeta o objeto. Eu literalmente nao preciso fazer nada, o spring faz tudo e posso usar os metodos do objeto criado.
	private UsuarioRepository usuarioRepository;

	
	
	public static void main(String[] args) {

		System.out.println("\n\nErik - Executando o metodo main e apos isso o metodo SpringApplication.run, que roda a aplicacao literalmente!\n\n");
		
		SpringApplication.run(MeuDecimoNonoProjetoApplication.class, args);
	
		
		System.out.println("\n\nErik - Finalizando a execucao do metodo main \n\n");	
		
	}	
	
	
	
	@Bean  //Esse metodo eh um utilitario que eh executado toda vez que o metodo "SpringApplication.run()" roda.
	public CommandLineRunner commandLineRunner() {
		
		
		System.out.println("\nErik - Executando o metodo 'commandLineRunner()' \n\n");
		
		
		//Expressao lambda maluca
		return args -> {
			

			
			//Usuario de teste com o perfil "ROLE_USUARIO".
			Usuario usuario = new Usuario();
			usuario.setEmail("usuario@email.com");
			usuario.setPerfil(PerfilEnum.ROLE_USUARIO);
			usuario.setSenha(SenhaUtils.gerarBCrypt("123456"));
			this.usuarioRepository.save(usuario);

			
			//Usuario de teste com o perfil "ROLE_ADMIN".			
			Usuario admin = new Usuario();
			admin.setEmail("admin@email.com");
			admin.setPerfil(PerfilEnum.ROLE_ADMIN);
			admin.setSenha(SenhaUtils.gerarBCrypt("123456"));
			this.usuarioRepository.save(admin);
			
			
			
			System.out.println("\nErik - Finalizando o metodo 'commandLineRunner()' \n\n");
			
		};
	}
	
	
}//class