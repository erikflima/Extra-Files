package com.erikcompany.api.security;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

//Classe utilizada pelo SpringSecurity para retorno, caso ocorra algum problema na autenticacao.

@Component  //Anotacao que do Spring, que diz para o Spring que essa classe sera um componente do Spring no qual ele pode acessar para obter informacoes.
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {
	
	

	@Override
	public void commence( HttpServletRequest      request, 
			              HttpServletResponse     response, 
			              AuthenticationException authException ) throws IOException {
		
		
		response.sendError( HttpServletResponse.SC_UNAUTHORIZED, "Acesso negado. Você deve estar autenticado no sistema para acessar a URL solicitada." );
	}
	
}