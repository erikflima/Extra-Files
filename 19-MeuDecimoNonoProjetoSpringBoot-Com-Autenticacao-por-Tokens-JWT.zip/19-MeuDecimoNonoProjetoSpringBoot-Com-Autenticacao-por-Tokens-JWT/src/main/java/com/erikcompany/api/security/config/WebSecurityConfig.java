package com.erikcompany.api.security.config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.erikcompany.api.security.JwtAuthenticationEntryPoint;
import com.erikcompany.api.security.filters.JwtAuthenticationTokenFilter;


@Configuration                                                          //Anotacao do Spring, que diz para o Spring que essa eh uma classe de configuracao. Ou seja, uma classe que o Spring vai rodar internamente e fazer algo.
@EnableWebSecurity                                                      //Habilita o security na minha aplicacao. Ou seja, vai comecar a validar todas as requisicoes.
@EnableGlobalMethodSecurity(prePostEnabled = true)                      //Fazer validacao por metodo utlizando o pre autorized
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {   //
	

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private JwtAuthenticationEntryPoint unauthorizedHandler;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private UserDetailsService userDetailsService;

	//1º A SER EXECUTADO
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	public void configureAuthentication( AuthenticationManagerBuilder authenticationManagerBuilder ) throws Exception {
		
		authenticationManagerBuilder.userDetailsService(this.userDetailsService).passwordEncoder( passwordEncoder() );
	}

	
	
	
	//2º A SER EXECUTADO. O proprio SpringBoot chama esse metodo sozinho, para configuracao da aplicacao.
	@Bean    // Anotação utilizada em cima dos métodos de uma classe, geralmente marcada com @Configuration, indicando que o Spring sozinho deve invocar esse metodo e gerenciar o objeto retornado por ele. Quando digo gerenciar é que agora este objeto pode ser injetado em qualquer ponto da sua aplicação.
	public PasswordEncoder passwordEncoder() {
		
		
		return new BCryptPasswordEncoder();
	}

	
	//3º A SER EXECUTADO. O proprio SpringBoot chama esse metodo sozinho, para configuracao da aplicacao.         
	@Bean    // Anotação utilizada em cima dos métodos de uma classe, geralmente marcada com @Configuration, indicando que o Spring sozinho deve invocar esse metodo e gerenciar o objeto retornado por ele. Quando digo gerenciar é que agora este objeto pode ser injetado em qualquer ponto da sua aplicação.
	public JwtAuthenticationTokenFilter authenticationTokenFilterBean() throws Exception { //Metodo que vai interceptar todas as requisicoes.
		
		JwtAuthenticationTokenFilter jwtAuthenticationTokenFilter = new JwtAuthenticationTokenFilter();
		
		
		return jwtAuthenticationTokenFilter;
	}

	
	//4º A SER EXECUTADO. O proprio SpringBoot chama esse metodo sozinho, para configuracao da aplicacao.
	@Override //TENTAR ARRUMAR O METODO AI DE BAIXO
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		
		
		httpSecurity.csrf().disable()                                                  //Desabilitando o csrf
		            .exceptionHandling().authenticationEntryPoint(unauthorizedHandler) //No caso de uma excecao, jogue a excessao "unauthorizedHandler"
		            .and()
				    .sessionManagement().sessionCreationPolicy( SessionCreationPolicy.STATELESS )//Dizendo que a minha sessao sera stateless, e nao guarda estado nenhum.
				    .and()
				    .authorizeRequests()
				    .antMatchers("/auth/**").permitAll() //Todas as request que forem feitas para as uri's que comecarem com "/auth/", nao precisazam passar pela autenticacao
				    .anyRequest().authenticated();       //Aqui eu digo que qualquer request devera passar pela autenticacao
		
		
		
		/*Tentando fazer aslinhas de cima do meu jeito!
		CsrfConfigurer<HttpSecurity>                                                      csrfConfigurerExtraido                = httpSecurity.csrf();
		HttpSecurity                                                                      httpSecurityExtraido                  = csrfConfigurerExtraido.disable();
		ExceptionHandlingConfigurer<HttpSecurity>                                         exceptionHandlingConfigurerExtraido1  = httpSecurityExtraido.exceptionHandling();
		ExceptionHandlingConfigurer<HttpSecurity>                                         exceptionHandlingConfigurerExtraido2  = exceptionHandlingConfigurerExtraido1.authenticationEntryPoint(unauthorizedHandler);
		HttpSecurity                                                                      httpSecurityExtraido2                 = exceptionHandlingConfigurerExtraido2.and();
		SessionManagementConfigurer<HttpSecurity>                                         sessionManagementConfigurerExtraido1  = httpSecurityExtraido2.sessionManagement();
		SessionManagementConfigurer<HttpSecurity>                                         sessionManagementConfigurerExtraido2  = sessionManagementConfigurerExtraido1.sessionCreationPolicy( SessionCreationPolicy.STATELESS );
		HttpSecurity                                                                      httpSecurityExtraido3                 = sessionManagementConfigurerExtraido2.and();
		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry expressionUrlAuthorizationConfigurer1 = httpSecurityExtraido3.authorizeRequests();
		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.AuthorizedUrl                  expressionUrlAuthorizationConfigurer2 = expressionUrlAuthorizationConfigurer1.antMatchers("/auth/**");
		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry expressionUrlAuthorizationConfigurer3 = expressionUrlAuthorizationConfigurer2.permitAll();
		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.AuthorizedUrl                  expressionUrlAuthorizationConfigurer4 = expressionUrlAuthorizationConfigurer3.anyRequest();
		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry expressionUrlAuthorizationConfigurer  = expressionUrlAuthorizationConfigurer4.authenticated();
		*/
		
		
		httpSecurity.addFilterBefore( authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class); //Adicionando um filtro de autenticacao.
		
		httpSecurity.headers().cacheControl(); //Colocando um controle de cache.
	}

}