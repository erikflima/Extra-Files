package com.erikcompany.api.security.controllers;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.erikcompany.api.response.Response;
import com.erikcompany.api.security.dto.JwtAuthenticationDto;
import com.erikcompany.api.security.dto.TokenDto;
import com.erikcompany.api.security.utils.JwtTokenUtil;


@RestController                           //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping("/auth")                  //Anotacao do Spring que uso para definir qual sera o caminho do endpoint.
@CrossOrigin(origins = "*")               //Faz esse controller aceitar requisicoes vinda de qualquer origem, seja ele um browser, app, etc,...desde que seja http. Na dúvda consultar -> http://andreybleme.com/2016-11-27/cors-spring/
public class AuthenticationController {
	
	

	private static final Logger log           = LoggerFactory.getLogger(AuthenticationController.class);
	private static final String TOKEN_HEADER  = "Authorization";
	private static final String BEARER_PREFIX = "Bearer ";

	
	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private AuthenticationManager authenticationManager;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private JwtTokenUtil jwtTokenUtil;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private UserDetailsService userDetailsService;

	
	
	
	               //Metodo que gera e retorna um novo token JWT.
	               //@PostMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@GetMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
                   //@RequestBody  -> Essa anotacao faz com que ao receber a requisicao, o que estiver no body da requisicao vai ser jogado dentro do objeto "empresaDtoRecebida", pra que eu posso manipular esse objeto depois. 
                   //@Valid        -> Faz com que o parametro seja validado automaticamente pelo hibernate validator(que sao anotacoes), baseado nas anotacoes de validacao que estao na classe do paramentro.
                   //BindingResult -> Trabalha junto com a anotacao @Valid. Se o hibernate validator(que sao anotacoes) realizar as validacoes e achar algum erro, ele vai se encarregar de me passar um objeto "BindingResult" ai dentro do metodo. Se nao tiver nenhum erro, o objeto "BindingResult" fica vazio.
	@PostMapping   
	public ResponseEntity< Response<TokenDto> > gerarTokenJwt( @Valid @RequestBody JwtAuthenticationDto authenticationDto,
			                                                                       BindingResult        resultadoDaValidacao            ) throws AuthenticationException {
		
		
		Response<TokenDto> responsePadronizado = new Response<TokenDto>();

		
		//Verificando a validacao dos dados de entrada feita automaticamente pelo Hibernate, com base nas anotacoes feitas na classe "EmpresaDto".
		if ( resultadoDaValidacao.hasErrors() ) {
			
			
			log.error("Erro validando lançamento: {}", resultadoDaValidacao.getAllErrors());
			
			
			//A variavel "resultadoDaValidacao" eh enviado pela validacao que o Spring fez, baseado nas anotacoes de validacao que estao la na classe "EmpresaDto".
			//Entao, pego a lista de erros dessa variavel.
			List<ObjectError> listaDeErros = resultadoDaValidacao.getAllErrors();
			
			
			for( ObjectError auxiliar : listaDeErros  ){
				
				//Pego a mensagem de erro da posicao atual.
				String mensagemDeErroExtraida = auxiliar.getDefaultMessage();
						
				responsePadronizado.getErrors().add(mensagemDeErroExtraida);
			}
	
			
			
			/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo badRequest(), ja deixa esse objeto com status code +400-Bad Request.
			 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
			 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
			*/			
			return ResponseEntity.badRequest().body(responsePadronizado);
			
		}

		
		
		log.info("Gerando token para o email {}.", authenticationDto.getEmail() );
		
		
		//Criando um objeto "UsernamePasswordAuthenticationToken" para o e-mail e senha recebidos
		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken( authenticationDto.getEmail(), authenticationDto.getSenha() );
		
		//Criando um objeto "Authentication". Que eh literalmente uma autorizacao que vou dar para a requisicao do usuario.
		Authentication authentication = authenticationManager.authenticate(	usernamePasswordAuthenticationToken );
		
		
		//Aqui eu seto a autenticacao dentro desse contexto estranho ai.
		SecurityContextHolder.getContext().setAuthentication( authentication );

		
		//Crio um objeto com os detalhes do usuario.
		UserDetails userDetails = userDetailsService.loadUserByUsername( authenticationDto.getEmail() );
		
		
		//Por fim gero o maldito token.
		String token = jwtTokenUtil.obterToken( userDetails );
		
		
		//Jogo o token criado dentro do "TokenDto".
		TokenDto tokenDto = new TokenDto(token);
		
		//Por fim, eu jogo o tokenDto dentro do response.
		responsePadronizado.setConteudoDoResponse(tokenDto);

		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
		*/
		return ResponseEntity.ok().body(responsePadronizado);		
	}

	

	                                     //Gera um novo token com uma nova data de expiracao. Ou seja, se o usuario estiver um token que vai expirar, basta ele me mandar o token que esta para expirar e eu vou devolver um novo token pra ele.
	                                     //@PostMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@GetMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	@PostMapping(value = "/refresh")     
	public ResponseEntity< Response<TokenDto> > gerarRefreshTokenJwt( HttpServletRequest request ) {
		
		
		
		log.info("Gerando refresh token JWT.");
		
		Response<TokenDto> responsePadronizado = new Response<TokenDto>();
		
		
		//Extrai o token do header que veio na requisicao.
		Optional<String> token = Optional.ofNullable( request.getHeader(TOKEN_HEADER) );

		
		
		if ( token.isPresent() && token.get().startsWith(BEARER_PREFIX) ) {
			
			token = Optional.of( token.get().substring(7) );
		}

		
		
		if ( !token.isPresent() ) {
			
			responsePadronizado.getErrors().add("Token não informado.");
			
			
		} else if ( !jwtTokenUtil.tokenValido(token.get() ) ) {
			
			responsePadronizado.getErrors().add("Token inválido ou expirado.");
		}

		
		
		//Se rolar algum erro, entao devolve bad request.
		if ( !responsePadronizado.getErrors().isEmpty() ){

			
			/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo badRequest(), ja deixa esse objeto com status code +400-Bad Request.
			 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
			 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
			*/				
			return ResponseEntity.badRequest().body( responsePadronizado );
			
		}

		
		//Gera  um novo token.
		String refreshedToken = jwtTokenUtil.refreshToken( token.get() );
		
		//Coloca o novo token dentro do tokenDto
		TokenDto tokenDto = new TokenDto( refreshedToken );
		
		//Coloca o tokenDto dentro da responta.
		responsePadronizado.setConteudoDoResponse( tokenDto );

		
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
		*/
		return ResponseEntity.ok().body( responsePadronizado );	
		
		
	}

}