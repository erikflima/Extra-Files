package com.erikcompany.api.security.dto;

//-----Classe DTO responsavel por guardar os dados que chegaram pela requisicao-----//
public class TokenDto {
	

	private String token; 


	
	public TokenDto() {
	}
	
	
	public TokenDto(String token) {
		this.token = token;
	}

	
	//-------------------------Getters and Setters----------------------//	
	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}