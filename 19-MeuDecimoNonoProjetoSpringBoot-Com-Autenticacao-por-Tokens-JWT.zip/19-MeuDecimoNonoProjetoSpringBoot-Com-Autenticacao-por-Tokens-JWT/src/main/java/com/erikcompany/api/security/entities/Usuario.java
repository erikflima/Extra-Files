package com.erikcompany.api.security.entities;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.erikcompany.api.security.enums.PerfilEnum;


@Entity                                         //Isso eh uma anotacao do Hibernate, no qual estou dizendo que essa classe reprenta um tabela do banco de dados.
@Table(name = "usuario")                        //Nome da tabela que essa classe representa.
public class Usuario implements Serializable {  //Serializable eh uma frescura do java. Essa implamentacao ajuda a performance do java se internamente ele precisar serializar um objeto dessa classe.

	
	
	private static final long serialVersionUID = 306411570471828345L; //Numero gerado pelo Java automaticamente.

	
	@Id                                             //Anotacao do Hibernate, no qual estou dizendo que o campo "id" eh o campo chave da tabela.
	@GeneratedValue(strategy = GenerationType.AUTO) //Anotacao do Hibernate que diz que o campo "id" campo eh Auto-incrementado.E o "Strategy" eh pra dizer como que vai ser esse auto-incremento.	
	private Long id;
	
	@Column(name = "email", nullable = false)
	private String email;
	
	@Column(name = "senha", nullable = false)
	private String senha;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "perfil", nullable = false)
	private PerfilEnum perfil;

	
	
	public Usuario() {
	}

	
	//-----------------Getters and Setters-----------------//
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	
	public PerfilEnum getPerfil() {
		return perfil;
	}

	public void setPerfil(PerfilEnum perfil) {
		this.perfil = perfil;
	}

	
	
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

}