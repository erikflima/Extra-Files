package com.erikcompany.api.security.enums;


//Classe que so serve para listar os perfeis de acesso existentes.
public enum PerfilEnum {
	
	ROLE_ADMIN,      //Perfil de administrador. Eu que inventei.
	ROLE_USUARIO;    //Peril de usuario. Eu que inventei.
}