package com.erikcompany.api.security.filters;
import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.erikcompany.api.security.utils.JwtTokenUtil;



/* Classe responsavel por validar as requisicoes */
public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {

	
	private static final String AUTH_HEADER   = "Authorization";  //Nome do header
	private static final String BEARER_PREFIX = "Bearer ";        //

	
	@Autowired
	private UserDetailsService userDetailsService;

	
	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	
	
	
	//Metodo chamado em toda requisicao que precisa de validacao.
	@Override
	protected void doFilterInternal( HttpServletRequest  request, 
			                         HttpServletResponse response, 
			                         FilterChain chain            ) throws ServletException, IOException {
		
		
		String token = request.getHeader(AUTH_HEADER); //Pega o token que veio no header da requisicao.
		
		
		if ( token != null && token.startsWith(BEARER_PREFIX) ) {
			
			token = token.substring(7); //Extrai o texto inicial que sera "Bearer ".
		}
		
		
		String username = jwtTokenUtil.getUsernameFromToken(token); //Pega o nome de usuario que do token.

		
		
		//Aqui eh a etapa que eu tento validar o token para ver se esta tudo certo e tals
		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			
			
			//Pego os detalhes do usuario.
			UserDetails userDetails = this.userDetailsService.loadUserByUsername( username );

			
			if ( jwtTokenUtil.tokenValido(token) ) { //Se o token for valido...
				
				
				//Criando um objeto "UsernamePasswordAuthenticationToken".
				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken( userDetails, null, userDetails.getAuthorities() );
				
				//Crio um objeto "WebAuthenticationDetails". Que eh praticamente dados gerados para dar autorizacao a requisicao recebida.
				WebAuthenticationDetails permissaoParaARequisicao = new WebAuthenticationDetailsSource().buildDetails(request);
				
				//Aqui eu vinculo a "permissaoParaARequisicao"		
				authentication.setDetails( permissaoParaARequisicao ) ;
				
				//Por fim, dou acesso a requisicao do usuario, pois no final de tudo o token eh valido. E ai o fluxo continua e tals.
				SecurityContextHolder.getContext().setAuthentication( authentication );
			}
			
		}

		//Nao sei o que essa instrucao faz. 
		chain.doFilter( request, response );
	}

}