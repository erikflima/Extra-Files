package com.erikcompany.api.security.services.impl;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.erikcompany.api.security.JwtUser;
import com.erikcompany.api.security.JwtUserFactory;
import com.erikcompany.api.security.entities.Usuario;
import com.erikcompany.api.security.services.UsuarioService;



@Service  //Anotacao do Spring que transforma essa classe em um "service". Ou seja, agora essa classe pode ser injetada em outros lugares.
public class JwtUserDetailsServiceImpl implements UserDetailsService { //UserDetailsService -> Classe do SpringSecurity que sou obrigado a implementar.

	
	@Autowired
	private UsuarioService usuarioService;

	
	
	@Override // Esse metodo vai ser chamado pelo SpringSecurity internamente.
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
		Optional<Usuario> funcionario = usuarioService.buscarPorEmail( username );

		
		if ( funcionario.isPresent() ) {
			
			
			
			JwtUser jwtUser = JwtUserFactory.create( funcionario.get() );
			
			
			return jwtUser;
		}

		throw new UsernameNotFoundException("Email não encontrado.");
	}

}