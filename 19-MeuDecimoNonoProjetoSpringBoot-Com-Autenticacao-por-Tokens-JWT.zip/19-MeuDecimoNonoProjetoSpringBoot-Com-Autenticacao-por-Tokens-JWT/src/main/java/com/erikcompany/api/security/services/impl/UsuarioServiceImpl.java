package com.erikcompany.api.security.services.impl;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erikcompany.api.security.entities.Usuario;
import com.erikcompany.api.security.repositories.UsuarioRepository;
import com.erikcompany.api.security.services.UsuarioService;


@Service //Anotacao do Spring que transforma essa classe em um "service". Ou seja, agora essa classe pode ser injetada em outros lugares.
public class UsuarioServiceImpl implements UsuarioService {


	@Autowired
	private UsuarioRepository usuarioRepository;
	

	
	public Optional<Usuario> buscarPorEmail( String emailRecebido ) {
	
		
		
		//Aqui eu faco um select na tabela usuario no banco de dados.
		Usuario usuarioRetornado = this.usuarioRepository.findByEmail( emailRecebido );
		
		
		return Optional.ofNullable( usuarioRetornado );
	}
	
}