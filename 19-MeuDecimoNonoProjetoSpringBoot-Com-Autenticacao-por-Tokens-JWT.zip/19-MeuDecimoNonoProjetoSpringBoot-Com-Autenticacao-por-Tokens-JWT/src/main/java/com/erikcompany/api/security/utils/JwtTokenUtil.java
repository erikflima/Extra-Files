package com.erikcompany.api.security.utils;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


//Classe responsavel por fazer todo controle do esquema de token.


@Component  //Anotacao que do Spring, que diz para o Spring que essa classe sera um componente do Spring no qual ele pode acessar para obter informacoes.
public class JwtTokenUtil {

	
	//Definindo 3 campos que ficam dentro do token que vou gerar. Estes campos tem obrigatoriamente que ter esses nomes ai mesmo.
	static final String CLAIM_KEY_USERNAME = "sub";     //Email de quem esta autenticando.
	static final String CLAIM_KEY_ROLE     = "role";    //Perfil de quem esta autenticando.
	static final String CLAIM_KEY_CREATED  = "created"; //Definicao de quando foi criado
	
	
	@Value("${jwt.secret}") //Pegando o valor da constante "jwt.secret" que esta la no arquivo "application.properties".
	private String secret;

	@Value("${jwt.expiration}") //Pegando o valor da constante "jwt.expiration" que esta la no arquivo "application.properties".
	private Long expiration;

	
	
	
	// Obtem o username (email) contido no token JWT.
	public String getUsernameFromToken( String tokenRecebido ) {
		
		
		String usernameExtraidoDoToken;
		
		
		try {
			
			//Esse tipo "Claims" eh so um objeto que guarda os atributos dentro do token.
			Claims atributosExtraidosDoTokenRecebido = getClaimsFromToken( tokenRecebido );
		
			usernameExtraidoDoToken = atributosExtraidosDoTokenRecebido.getSubject();
		
		} catch (Exception e) {
			
			
			System.out.println("\n\n\nRetonando um token 'null'. Pois ocorreu uma exception na classe 'JwtTokenUtil': " +e+ "\n\n\n");
			
			usernameExtraidoDoToken = null;
		}
		
		return usernameExtraidoDoToken;
	}

	
	
	
	//Retorna a data de expiracao de um token JWT.
	public Date getExpirationDateFromToken(String tokenRecebido) {
		
		Date dataDeExpiracaoDoTokenRecebido;
		
		try {
		
			//Esse tipo "Claims" eh so um objeto que guarda os atributos dentro do token.
			Claims atributosExtraidosDoTokenRecebido = getClaimsFromToken(tokenRecebido);
			
			dataDeExpiracaoDoTokenRecebido = atributosExtraidosDoTokenRecebido.getExpiration();
		
			
		} catch (Exception e) {
		
			
			dataDeExpiracaoDoTokenRecebido = null;
		}
		
		return dataDeExpiracaoDoTokenRecebido;
	}

	
	
	//Cria um novo token (refresh).
	public String refreshToken(String token) {
		
		
		String refreshedToken;
		
		try {
			
			//Esse tipo "Claims" eh so um objeto que guarda os atributos dentro do token.
			Claims atributosExtraidosDoTokenRecebido = getClaimsFromToken( token );
			
			atributosExtraidosDoTokenRecebido.put( CLAIM_KEY_CREATED, new Date() ); //Aqui dou a data atual para o token.
			
			
			//Gera um novo token???????
			refreshedToken = gerarToken( atributosExtraidosDoTokenRecebido );
			
			
		} catch (Exception e){
			
			refreshedToken = null;
		}
		
		
		return refreshedToken;
	}

	
	
	//Verifica se um token JWT é válido.
	public boolean tokenValido( String tokenRecebido ){
		
		
		//Se o token nao estiver expirado.
		boolean resposta = !tokenExpirado( tokenRecebido );
		
		return resposta;
	}

	
	
	//Retorna um novo token JWT com base nos dados do usuarios.
	public String obterToken( UserDetails userDetails ) {
		
		
		//Esse aqui vai ser o mapa que vai conter os atributos do token que vou gerar e retornar.
		Map<String, Object> atributosDoTokenAserGerado = new HashMap<>();
		
		
		//Colocando o nome do usuario dentro do mapa.
		atributosDoTokenAserGerado.put( CLAIM_KEY_USERNAME, userDetails.getUsername() );

		//Colocando a data de criacao no mapa.
		atributosDoTokenAserGerado.put( CLAIM_KEY_CREATED, new Date() );
		
	
		
		//Colocando os perfis de usuario no mapa.  Ficou meio esquisito, mas tem que ser assim mesmo. ---------//
		
		/*A premissa eh o seguinte:
		 Collection eh uma interface!
		 GrantedAuthorityeh uma interface!
		 Conclusao: "listaDePerfis"  eh uma instancia de uma classe que implementa a interface "Collection"
		             que se torna lista. E essa lista guarda objetos de uma clase(que eu nao qual eh) que implementa 
		             a interface GrantedAuthority. Ou seja, tudo eh abstrato nessa bosta.  
		             Eh melhor dizer que tenho uma lista na minha mao e ja era.                          		*/
		Collection<? extends GrantedAuthority> listaDePerfis = userDetails.getAuthorities();
		
	    for( GrantedAuthority auxiliar : listaDePerfis ){  
	    
	    	atributosDoTokenAserGerado.put( CLAIM_KEY_ROLE, auxiliar.getAuthority() );
		} 
		
			
	    
	    //Com base no mapa que eu passei, eh gerado um token.
		String tokenGeradoAserRetornado = gerarToken( atributosDoTokenAserGerado );
		
		return tokenGeradoAserRetornado;
	}


	
	
	
	// Pega os campos que estao dentro no body do token JWT recebido.
	private Claims getClaimsFromToken( String tokenRecebido ) {
		
		//Esse tipo "Claims" eh so um objeto que guarda os atributos dentro do token.
		Claims atributosExtraidosDoTokenRecebido;
		
		try {
			
			//Aqui eu tento extrarir os campos que estao dentro do token que recebi. Para extrair, eu preciso dizer o "secret", que a string chave que serve para descriptografar o token.
			atributosExtraidosDoTokenRecebido = Jwts.parser().setSigningKey( secret ).parseClaimsJws( tokenRecebido ).getBody();
		
		} catch (Exception e) {
		
			
			System.out.println("\n\n Nao foi possivel extrair os atributos do token. Pois ocorreu uma exception no metodo 'getClaimsFromToken' da classe 'JwtTokenUtil': " +e+ "\n\n\n");

			atributosExtraidosDoTokenRecebido = null;
		}
		
		
		return atributosExtraidosDoTokenRecebido;
	}

	
	
	//Retorna a data de expiração com base na data atual.
	private Date gerarDataExpiracao() {
		
		
		//Pega o momento atual em segundos.
		long momentoAtualEmSegundos = System.currentTimeMillis();
		
		//Aqui eu defino a data de expiracao do token. Ou seja, ate quando que o token vai ser valido.
		//Entao eu digo que a validade do token, vai ser o momento atul + o periodo que defini na variavel "expiration".
		//Nao entendi para que o " * 1000", mas de boa entao.
		Date dataDeExpiracao = new Date( momentoAtualEmSegundos + expiration * 1000);
		
		return dataDeExpiracao;
	}

	
	
	
	
	
	//Verifica se o token recebido esta expirado ou nao.
	// Verifica se um token JTW está expirado.
	private boolean tokenExpirado(String token) {
	
		
		Date dataExpiracao = this.getExpirationDateFromToken(token);

		
		if ( dataExpiracao == null ) {
			
			//Se nao tiver data de expiracao, entao o token nao esta expirado.
			return false;
		}
		
		//Verifica se a data de expericao do token eh menor que a data de hoje.
		boolean resposta =  dataExpiracao.before( new Date() );
		
		return resposta;
	}

	
	
	
	//Gerar Token apartir de um mapa de atributos.
	//Gera um novo token JWT contendo os dados (claims) fornecidos.
 	private String gerarToken( Map<String, Object> atributosParaOToken ) {
		
		
		//Aqui eu uso a biblioteca jjwt para criar um token.
		String tokenGeradoAserRetornado = Jwts.builder().setClaims( atributosParaOToken )              //Passo os atributos que vao formar o token.
				                                        .setExpiration( gerarDataExpiracao() )         //Passo a data de expiracao do token.
				                                        .signWith( SignatureAlgorithm.HS512, secret )  //Passo qual algoritmo eu quero que a biblioteca do jjwt use para criar e criptografar o token, e passo o secret( que eh a chave em formato string que inventei) que o algortimo vai usar para criar e criptografar o token. Ai quem for descriptografar o token, vai precisar dessa chave ai.
				                                        .compact();
		
		return tokenGeradoAserRetornado;
	}



}//class.