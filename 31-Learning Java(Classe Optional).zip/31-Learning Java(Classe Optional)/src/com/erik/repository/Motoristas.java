package com.erik.repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.erik.model.Caminhao;
import com.erik.model.Motorista;
import com.erik.model.Seguro;



// Classe que vai ser o meu banco de dados de motoristas em formato Map.
public class Motoristas {

	
	private Map<String, Optional<Motorista> > motoristas = new HashMap<>();

	
	//Construtor
	public Motoristas() {
		
		Seguro              seguro        = new Seguro(  "Parcial - nao cobre roubo", new BigDecimal("5000")      );
		Caminhao            caminhao      = new Caminhao("Mercedes Atron",            Optional.ofNullable(seguro) );
		
		Optional<Motorista> motoristaJoao = Optional.of( new Motorista( "Joao", 40, Optional.ofNullable( caminhao) ) );
		Optional<Motorista> motoristaJose = Optional.of( new Motorista( "Jose", 25, Optional.ofNullable( null    ) ) );

		
		motoristas.put( "Joao", motoristaJoao );
		motoristas.put( "Jose", motoristaJose );
	}

	
	
	//-----------------Getters and Setters-----------------//
	
	public Optional<Motorista> porNome( String nome ) {
		
		
		Optional<Motorista> optionalReposta = motoristas.get(nome);
		
		return optionalReposta;
	}

}
