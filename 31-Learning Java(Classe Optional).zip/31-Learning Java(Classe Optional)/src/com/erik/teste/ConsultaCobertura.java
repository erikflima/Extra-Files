package com.erik.teste;
import java.util.Optional;
import com.erik.model.Caminhao;
import com.erik.model.Motorista;
import com.erik.model.Seguro;
import com.erik.repository.Motoristas;




public class ConsultaCobertura {

	
	public static void main(String[] args) {
		
		
		Motoristas motoristas = new Motoristas();
		// Motorista motorista = motoristas.porNome("Joao");
		
		//String cobertura = motorista.getCaminhao().getSeguro().getCobertura();
		/*String cobertura = "Sem seguro";
		if (motorista != null) {
		
			Caminhao caminhao = motorista.getCaminhao();
			
			if (caminhao != null) {
			
				Seguro seguro = caminhao.getSeguro();
				
				if (seguro != null) {
				
					cobertura = seguro.getCobertura();
				}
			}
		}*/
		
		String cobertura = motoristas.porNome("Joao").flatMap(Motorista::getCaminhao)
								                     .flatMap(Caminhao::getSeguro)
								                     .map(Seguro::getCobertura)
								                     .orElse("Sem cobertua");
		
		System.out.println("A cobertura eh: " + cobertura);
	}
	
}