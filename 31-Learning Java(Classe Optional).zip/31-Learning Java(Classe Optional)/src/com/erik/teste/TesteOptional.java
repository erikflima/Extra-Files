package com.erik.teste;
import java.math.BigDecimal;
import java.util.Optional;
import com.erik.model.Seguro;



public class TesteOptional {

	public static void main(String[] args) {
		
		
		Seguro seguro1  = new Seguro( "Total com franquia reduzida", new BigDecimal("600") );
		Seguro seguro2  = null;

		
		
		/*A meta eh evitar o "null pointer exception"
		  Aqui eu crio uma variavel do tipo "Optional" que guarda um objeto do tipo "Seguro".
		  O Opcional eh como se fosse uma caixa, ele pode receber um objeto do tipo "Seguro" preenchido ou preenchido com "null". 
		  E ai eu ganho metodos que podem trabalhar com o valor que esta dentro da caixa. 
		*/
		Optional<Seguro> seguroOptional = Optional.ofNullable( seguro1 );

		
		
		/*Agora eu quero imprimir o valor do campo "valorFranquia" do objeto do tipo "Seguro" que esta dentro do "seguroOptional". 
		 Entao eu chamo o metodo "map()" e peco para ele chamar o metodo "getValorFranquia()" que por fim me retorna um BigDecimal. 
		 
		 * */
		Optional<BigDecimal> valorFranquiaOptional = seguroOptional.map( Seguro::getValorFranquia );
		
		
		
		//Se a variavel "valorFranquiaOptional" possui algo dentro dela que nao seja "null", entao imprimir esse valor na tela.
		//Caso contrario nao faca nada.
		valorFranquiaOptional.ifPresent( System.out::println );
		
	}
	
}
