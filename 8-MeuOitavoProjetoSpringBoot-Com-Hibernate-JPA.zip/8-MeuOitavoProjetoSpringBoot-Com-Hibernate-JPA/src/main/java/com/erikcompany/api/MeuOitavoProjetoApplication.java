package com.erikcompany.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.erikcompany.api.entities.Empresa;
import com.erikcompany.api.repositories.EmpresaRepository;

//Classe principal que de fato executa o projeto.


@SpringBootApplication //Anotacao do Spring Boot que faz tudo acontecer. Inicializa o Spring Boot, componentes, entre outras coisas.
public class MeuOitavoProjetoApplication {
	
	
	@Autowired //Anotacao do Spring que injeta o objeto. Eu literalmente nao preciso fazer nada, o spring faz tudo e posso usar os metodos do objeto criado.
	private EmpresaRepository empresaRepository;

	
	
	public static void main(String[] args) {
		
		System.out.println("\n\nErik - Executando o metodo main e apos isso o metodo SpringApplication.run, que roda a aplicacao literalmente!\n\n");
		
		SpringApplication.run(MeuOitavoProjetoApplication.class, args);
		
		System.out.println("\n\nErik - Finalizando a execucao do metodo main \n\n");	
	}

	
	
	
	@Bean  //Esse metodo eh um utilitario que eh executado toda vez que o metodo "SpringApplication.run()" roda.
	public CommandLineRunner commandLineRunner() {
		
		//Expressoa lambda maluca
		return args -> {
			
			System.out.println("\nErik - Executando o metodo 'commandLineRunner()' \n\n");	
			
			Empresa empresa = new Empresa();
			empresa.setRazaoSocial("Kazale IT");
			empresa.setCnpj("74645215000104");
			
			
			this.empresaRepository.save( empresa ); //Fazer o insert no banco de dados. Ou update se o objeto a ser salvo ja existir no banco.

            
			List<Empresa> empresas = empresaRepository.findAll(); //Seleciona todas as empresas da tabela.

			for(Empresa aux : empresas ){
				aux.toString(); 
			}
			
			
			Empresa empresaDb = empresaRepository.findOne(1L); //Seleciona apenas uma resultado no banco pelo id(Que eh a chave primaria).
			System.out.println("Empresa por ID: " + empresaDb);
			
			
			empresaDb.setRazaoSocial("Kazale IT Web");
			this.empresaRepository.save(empresaDb); //Fazer o update no banco de dados. Ou insert se o objeto a ser salvo nao existir no banco.

			
			Empresa empresaCnpj = empresaRepository.findByCnpj("74645215000104"); //Executando o metodo que criei.
			System.out.println("\n\nEmpresa por CNPJ: " + empresaCnpj);
			
			this.empresaRepository.delete(1L); //Deletando da tabela a linha com id=1.
			
			empresas = empresaRepository.findAll();
			System.out.println("\n\nQuantidade de linhas na tabela 'Empresa' : " + empresas.size() );

			
			System.out.println("\nErik - Finalizando o metodo 'commandLineRunner()' \n\n");
		};
	}
}
