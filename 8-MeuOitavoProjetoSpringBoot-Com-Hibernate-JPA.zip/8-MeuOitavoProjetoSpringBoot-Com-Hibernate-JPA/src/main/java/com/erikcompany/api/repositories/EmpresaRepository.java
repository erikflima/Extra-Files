package com.erikcompany.api.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import com.erikcompany.api.entities.Empresa;

/*
O que eu quero eh criar um objeto que tenha metodos que acessa uma tabela no meu banco de dados, blz!
Entao eu crio um interface, que extend que herda de "JpaRepository" da biblioteca Hibernate-JPA.
Essa "JpaRepository" obriga o herdador a implementar um monte de metodos. 
Eh tipo um esqueminha, pq que vai implementar esse monte de metodos, eh o Spring, quando eu usar a anotacao "@Autowired" em alguma parte do codigo.

   Obs: -> JpaRepository<Classe da tabela que quero me conectar, Tipo da chave primaria da tabela> 
*/
public interface EmpresaRepository extends JpaRepository<Empresa, Long> {
	
	
	/*
	Metodo de implementacao obrigatoria que quero criar.
	 O fato de eu dar o nome do metodo como "findBy..." ja faz o Spring entender, que no momento que eu 
	 for injetar um objeto "EmpresaRepository" com a anotacao "@Autowired", a implementacao automatica desse
	 metodo vai ser assim:"select * from EMPRESA where cnpj = cnpjRecebidoPorParametro".
	 Bem foda ne! 
	*/
	Empresa findByCnpj(String cnpj);
	
	
	//Seria legal deixar a lista de metodos padrao que o Spring poe no objeto injetado. Tipo deixar comentado para que eu posso ver de boas.
	

}