-- Script que o FlyWay vai executar no banco MySQL.
-- ------------------------------------------------------

-- Criacao da tabela `empresa`.
CREATE TABLE `empresa` (

  `id`               bigint(20)   NOT NULL AUTO_INCREMENT,
  `ativo`            bit(1)       NOT NULL,
  `cnpj`             varchar(255) NOT NULL,
  `data_atualizacao` datetime     NOT NULL,
  `data_criacao`     datetime     NOT NULL,
  `quantidade`       int(11)      NOT NULL,
  `razao_social`     varchar(255) NOT NULL,
  
  PRIMARY KEY (`id`)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;