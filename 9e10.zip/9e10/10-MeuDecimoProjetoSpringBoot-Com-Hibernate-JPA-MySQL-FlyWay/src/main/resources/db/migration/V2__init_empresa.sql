-- Script que o FlyWay vai executar no banco MySQL.
-- ------------------------------------------------------

-- Inserts na `empresa`.
INSERT INTO `empresa` (`id`, `ativo`, `cnpj`, `data_atualizacao`,    `data_criacao`,        `quantidade`, `razao_social`) 
VALUES                (0,     1,      '123',  '2018-09-02 17:37:42', '2018-09-02 17:37:42',  100,          'Go to Canada');