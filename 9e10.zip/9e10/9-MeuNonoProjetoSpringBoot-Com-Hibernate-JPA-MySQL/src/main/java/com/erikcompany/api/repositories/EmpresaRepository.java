package com.erikcompany.api.repositories;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.erikcompany.api.entities.Empresa;

/*
O que eu quero eh criar um objeto que tenha metodos que acessa uma tabela no meu banco de dados, blz!
Entao eu crio um interface, que extend que herda de "JpaRepository" da biblioteca Hibernate-JPA.
Essa "JpaRepository" obriga o herdador a implementar um monte de metodos. 
Eh tipo um esqueminha, pq que vai implementar esse monte de metodos, eh o Spring, quando eu usar a anotacao "@Autowired" em alguma parte do codigo.

   Obs: -> JpaRepository<Classe da tabela que quero me conectar, Tipo da chave primaria da tabela> 
*/
public interface EmpresaRepository extends JpaRepository<Empresa, Long> {
	
	
	//Metodo no qual eu defino o conteudo. Esse eh so um exemplo simplao.
    @Query("select count(*) from Empresa")
    public int pegaTotalDeLinhasDaTabela();
    
    
	/*Metodos de implementacao obrigatoria que quero criar.
	   O fato de eu dar o nome do metodo como "findBy...", "readBy...", ou "getBy..." ja faz o Spring entender, que no momento que eu 
	   for injetar um objeto "EmpresaRepository" com a anotacao "@Autowired", a implementacao automatica desse
	   metodo vai ser assim:"select * from EMPRESA where cnpj = cnpjRecebidoPorParametro".
	   Bem foda ne! Na duvida consultar -> http://blog.algaworks.com/spring-data-jpa/
	*/
	public Empresa findByCnpj( String cnpj );  //Forma 1 de declarar o metodo
	
	public Empresa readByCnpj( String cnpj );  //Forma 2 de declarar o metodo
	
	public Empresa getByCnpj( String cnpj );   //Forma 3 de declarar o metodo
	
	public Empresa queryByCnpj( String cnpj ); //Forma 4 de declarar o metodo
	

    //Consultar por todos as empresas com razaoSocial que comecarem com a string passada no parametro. O proprio Spring Data JPA vai se encarregar de colocar o sinal de percentual.
    public List<Empresa> findByRazaoSocialStartingWith( String razaoSocial ); 


    //Consultar por todos as empresas com razaoSocial que comecarem com a string passada no parametro, e ordernar por Id
    List<Empresa> findByRazaoSocialStartingWithOrderById( String razaoSocial );   
    
    
    //Consultar por todos as empresas com razaoSocial que comecarem com a string passada no parametro, ignorando maisculas e minusculas.
    List<Empresa> findByRazaoSocialStartingWithIgnoreCase(String razaoSocial);    
    
    
    // Pesquisando por duas propriedades: razaoSocial e id.
    List<Empresa> findByRazaoSocialStartingWithIgnoreCaseAndIdEquals(String razaoSocial, Long id);
    
    
    // Nesse caso, precisamos usar o sinal de percentual em nossas consultas.
    List<Empresa> findByRazaoSocialLike(String razaoSocial);    
    
    
    // Podemos usar também IsNotNull ou NotNull.
    List<Empresa> findByRazaoSocialIsNull();    
    
    
    // Quando voce quer negar o que passa no parametro
    List<Empresa> findByRazaoSocialNot(String razaoSocial);   
    
    
    // Todos as empreas com os IDs passados no varargs. Poderia usar NotIn para negar os IDs.
    List<Empresa> findByIdIn(Long... ids);
    
    
    // Todos onde a propriedade ativo é true. Poderia ser falso, usando False.
    List<Empresa> findByAtivoTrue();
    
    
    // Buscar onde a data de cadastro é depois do parâmetro passado. 
    // Pode ser usado Before também.
    List<Empresa> findByDataCriacaoAfter( Date dataCriacao );   
    
    
    // Buscar onde a data cadastro está dentro de um período.
    List<Empresa> findByDataCriacaoBetween( Date data_inicio, Date data_fim );    
    
    
    // Todos com quantidade "menor que". Poderia ser usado
    // também LessThanEqual, GreaterThan, GreaterThanEqual.
    List<Empresa> findByQuantidadeLessThan( int quantidade );   

}