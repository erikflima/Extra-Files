CamStudio Portable 2.0
======================
Copyright 2004-2011 John T. Haller

Copyright 2006-2007 Geoff Shearsmith

Copyright 2008 Olver Krystal

Copyright 2011 JW Hough

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


ABOUT CAMSTUDIO PORTABLE
========================
The CamStudio Portable Launcher allows you to run CamStudio from a removable drive whose letter changes as you move it to another computer.  The program and the settings can be entirely self-contained on the drive and then used on any Windows computer.


LICENSE
=======
This code is released under the GPL.  Within the CamStudioPortableSource directory you will find the code (CamStudioPortable.nsi) as well as the full GPL license (License.txt).  If you use the launcher or code in your own product, please give proper and prominent attribution.


INSTALLATION / DIRECTORY STRUCTURE
==================================
By default, the program expects one of these directory structures:

-\ <--- Directory with CamStudioPortable.exe
	+\App\
	    +\CamStudio\
	+\Data\
		+\settings\

OR

-\ <--- Directory with CamStudioPortable.exe
	+\CamStudioPortable\
		+\App\
			+\CamStudio\
		+\Data\
			+\settings\

OR

-\ <--- Directory with CamStudioPortable.exe
	+\PortableApps\
		+\CamStudioPortable\
			+\App\
				+\CamStudio\
			+\Data\
				+\settings\

OR

-\ <--- Directory with CamStudioPortable.exe (PortableApps, for instance)
	+\Apps\
		+\CamStudioPortable\
			+\Ink\
	+\Data\
		+\CamStudioPortable\
			+\settings\


It can be used in other directory configurations by including the CamStudioPortable.ini file in the same directory as CamStudioPortable.exe and configuring it as details in the INI file section below.  The INI file may also be placed in a subdirectory of the directory containing CamStudioPortable.exe called CamStudioPortable or 2 directories deep in PortableApps\CamStudioPortable or Data\CamStudioPortable.  All paths in the INI should remain relative to the EXE and not the INI.


CamStudioPortable.INI CONFIGURATION
===================================
The CamStudio Portable Launcher will look for an ini file called CamStudioPortable.ini within its directory (see the paragraph above in the Installation/Directory Structure section).  If you are happy with the default options, it is not necessary, though.  There is an example INI included with this package to get you started.  The INI file is formatted as follows:

[CamStudioPortable]
CamStudioDirectory=App\CamStudio
SettingsDirectory=Data\settings
CamStudioExecutable=recorder.exe
AdditionalParameters=
DisableSplashScreen=false


The CamStudioDirectory and SettingsDirectory entries should be set to the *relative* path to the directories containing recorder.exe and your settings from the current directory.  All must be a subdirectory (or multiple subdirectories) of the directory containing CamStudioPortable.exe.  The default entries for these are described in the installation section above.

The SettingsFile entry is the name of your CamStudio settings file within the SettingsDirectory.

The CamStudioExecutable entry allows you to give an alternate filename for the CamStudio executable.

The AdditionalParameters entry allows you to specify additional parameters to be passed to CamStudio on the command line.

The DisableSplashScreen entry allows you to run the CamStudio Portable Launcher without the splash screen showing up.  The default is false.


PROGRAM HISTORY / ABOUT THE AUTHORS
===================================
This launcher is loosely based on the Firefox Portable launcher, which contains methods suggested by mai9 and tracon of the mozillaZine.org forums.

This project was originally created by Geoff Shearsmith, but he abandoned
it, so Oliver took over, but then he abandoned it, so now I (JW Hough) am
taking over. The above two did most of the work, I just made a couple
changes here and there and updated CamStudio to the most recent version
and brought the app up to PortableApps.com Format 2.0 specifications.