package Exemplo_interface_com_palavra_public;


/* Uma interface pode ter assinaturas de metodos
   Uma interface pode ter atributos   */
public interface ExemploInterface {
	
	
	
	//Posso declarar atributos em uma interface
	//A classe que herdar a interface "ExemploInterface" vai ganhar esses atributos
	//Porem nao vai dar para alterar(set) o valor desses atributos, mas da para pegar(get)
	 public String  nome    = "Erik";
	 public int     numero  = 150;
	 public boolean status  = false;

	 
	 
	/*A classe que herdar a interface "ExemploInterface" vai ter que implementar obrigatoriamente esses metodos:
     E lembrando que nao te como criar um metodo com instrucoes, so da para criar a assinatura do mesmo. */
	public void exibeMensagem( String mensagemASerExibida ); 
	
	public void exibeIdade( int idade ); 	
	
	public int devolveNumero( int senhaRecebida ); 
	
}
