package Exemplo_interface_com_palavra_public2;
import Exemplo_interface_com_palavra_public.ExemploInterface;

public class TesteOutroPacote implements ExemploInterface{

	public static void main(String[] args) {
				
		TesteOutroPacote variavel = new TesteOutroPacote();
		
		//Exibindo(dando um get) o valor dos atributos herdados da Interface "ExemploInterface"
		System.out.println( "Atributos herdados da Interface:" );
		System.out.println( variavel.nome   );
		System.out.println( variavel.numero );
		System.out.println( variavel.status );	
		
		//Nao da para mudar o valor dos atributos herdados de uma Interface :(
		//variavel.nome   = "Sakura";
		//variavel.numero = 200;
		//variavel.status = true;		
	}

	@Override
	public void exibeMensagem(String mensagemASerExibida) {

		System.out.println( "Implementando o metodo obrigatorio que veio da Interface" );
	}

	@Override
	public void exibeIdade(int idade) {
		
		System.out.println( "Implementando o metodo obrigatorio que veio da Interface" );		
	}

	@Override
	public int devolveNumero(int senhaRecebida) {

		System.out.println( "Implementando o metodo obrigatorio que veio da Interface" );
		
		return 1000;
	}
	
}
