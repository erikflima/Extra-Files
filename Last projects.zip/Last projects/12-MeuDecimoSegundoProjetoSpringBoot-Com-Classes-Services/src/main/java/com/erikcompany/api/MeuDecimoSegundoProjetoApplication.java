package com.erikcompany.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.erikcompany.api.services.ExemploService;



//Classe principal que de fato executa o projeto.


@SpringBootApplication //Anotacao do Spring Boot que faz tudo acontecer. Inicializa o Spring Boot, componentes, entre outras coisas.
public class MeuDecimoSegundoProjetoApplication {
	
	
	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private ExemploService exemploService;
	
	
	public static void main(String[] args) {

		System.out.println("\n\nErik - Executando o metodo main e apos isso o metodo SpringApplication.run, que roda a aplicacao literalmente!\n\n");
		
		SpringApplication.run(MeuDecimoSegundoProjetoApplication.class, args);
	
		System.out.println("\n\nErik - Finalizando a execucao do metodo main \n\n");	
		
	}

	
	
	       //Anotacao do Spring que diz que esse eh um metodo de configuracao para o Spring.
	@Bean  //Esse metodo eh um utilitario que eh executado toda vez que o metodo "SpringApplication.run()" roda.
	public CommandLineRunner commandLineRunner() {
		
		//Expressoa lambda maluca
		return args -> {
			
			System.out.println("\nErik - Executando o metodo 'commandLineRunner()' \n\n");	
			
			//Usando o objeto "Service" injetado. Essa classe deve conter a regra de negocio.
			this.exemploService.testarServico();
			
			
			System.out.println("\nErik - Finalizando o metodo 'commandLineRunner()' \n\n");
			
		};
	}	
		
}