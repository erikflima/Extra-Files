package com.erikcompany.api.services;

import org.springframework.stereotype.Service;


@Service //Anotacao do Spring que transforma essa classe em um "service". Ou seja, agora essa classe pode ser injetada em outros lugares.
public class ExemploService {

	
	/*OBS:  ideia eh que classes do tipo Service tenham a regra de negocio da aplicacao, e sejam chamadas pelos controllers.*/
	
	
	public void testarServico() {
		
		System.out.println("\n\n### Executando serviço de teste!!!### \n\n");
	}
	
}