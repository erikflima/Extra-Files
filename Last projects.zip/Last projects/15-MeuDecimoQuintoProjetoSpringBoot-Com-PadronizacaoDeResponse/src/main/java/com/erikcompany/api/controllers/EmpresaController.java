package com.erikcompany.api.controllers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.erikcompany.api.dtos.EmpresaDto;
import com.erikcompany.api.responses.ResponsePadronizado;


@RestController                  //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping("/api/empresas") //Anotacao do Spring que uso para definir qual sera o caminho do endpoint.
public class EmpresaController {

	
	Logger logger = LoggerFactory.getLogger( getClass() );	
	
	
	                             //@PostMapping -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@GetMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	                             //@RequestBody -> Essa anotacao faz com que ao receber a requisicao, o que estiver no body da requisicao vai ser jogado dentro do objeto "empresaDtoRecebida", pra que eu posso manipular esse objeto depois. 
	@PostMapping                
	public ResponseEntity< ResponsePadronizado<EmpresaDto> > cadastrar( @RequestBody EmpresaDto empresaDtoRecebida ) {
		

		logger.info("\nEntrando no metodo cadastrar\n");
		

		//Simulando uma alteracao no dto.
		empresaDtoRecebida.setId(300L);
		empresaDtoRecebida.setRazaoSocial("Teste de alteração");	
		empresaDtoRecebida.setCnpj("99999");

		
		//Preparando o objeto de resposta padronizada que criei.
		ResponsePadronizado<EmpresaDto> responsePadronizado = new ResponsePadronizado<EmpresaDto>();
		
		//Aqui eu coloco o objeto que quero de fato retornar, que eh o "empresaDtoRecebida", dentro dentro do objeto "responsePadronizado".
		responsePadronizado.setConteudoDoResponse( empresaDtoRecebida );
		
		
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity".
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
		*/
		return ResponseEntity.ok().body(responsePadronizado);
	}
	
	

}