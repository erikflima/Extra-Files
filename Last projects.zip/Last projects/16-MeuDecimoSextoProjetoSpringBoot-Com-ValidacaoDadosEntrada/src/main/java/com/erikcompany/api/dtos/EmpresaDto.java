package com.erikcompany.api.dtos;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.br.CNPJ;

//-----Classe DTO responsavel por guardar os dados que chegaram pela requisicao-----//

public class EmpresaDto {

	private Long   id;
	
	@NotEmpty(message = "Razão social não pode ser vazia.")                                         //Anotacao de validacao automatica do hibernate.
	@Length  (min = 5, max = 200, message = "Razão social deve conter entre 5 e 200 caracteres.")   //Anotacao de validacao automatica do hibernate.
	private String razaoSocial;
	
	@NotEmpty(message = "CNPJ não pode ser vazio.")  //Anotacao de validacao automatica do hibernate.
	@CNPJ    (message = "CNPJ inválido.")	         //Anotacao de validacao automatica do hibernate. Obs: Por incrivel que pareca, essa anotacao ai valida o cnpj sozinho.
	private String cnpj;

	
	
	public EmpresaDto() {
	}

//-------------------------Getters and Setters----------------------//	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	
	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	
	@Override
	public String toString() {
		
		return "\n\nDTO recebido: \nEmpresaDto \n id=" +id+ ", \n razaoSocial=" +razaoSocial+ ", \n cnpj=" +cnpj+ "\n\n";
	}
	
}