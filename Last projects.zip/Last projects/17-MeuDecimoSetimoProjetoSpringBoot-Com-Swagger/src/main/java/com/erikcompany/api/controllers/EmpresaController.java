package com.erikcompany.api.controllers;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.erikcompany.api.dtos.EmpresaDto;
import com.erikcompany.api.responses.ResponsePadronizado;


@RestController                                                                                  //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping(value="/api/empresas", produces="application/json", consumes="application/json") //Anotacao do Spring que uso para definir qual sera o caminho do endpoint. Digo que recebe json e produso json.
public class EmpresaController {
	
	
	Logger logger = LoggerFactory.getLogger( getClass() );	
	
	
	                             //@PostMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@GetMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	                             //@RequestBody  -> Essa anotacao faz com que ao receber a requisicao, o que estiver no body da requisicao vai ser jogado dentro do objeto "empresaDtoRecebida", pra que eu posso manipular esse objeto depois. 
                                 //@Valid        -> Faz com que o parametro seja validado automaticamente pelo hibernate validator(que sao anotacoes), baseado nas anotacoes de validacao que estao na classe do paramentro.
	                             //BindingResult -> Trabalha junto com a anotacao @Valid. Se o hibernate validator(que sao anotacoes) realizar as validacoes e achar algum erro, ele vai se encarregar de me passar um objeto "BindingResult" ai dentro do metodo. Se nao tiver nenhum erro, o objeto "BindingResult" fica vazio.
	@PostMapping                
	public ResponseEntity< ResponsePadronizado<EmpresaDto> > cadastrar(@Valid @RequestBody EmpresaDto    empresaDtoRecebida, 
			                                                                               BindingResult resultadoDaValidacao ) {
		

		logger.info("\nEntrando no metodo cadastrar\n");
		
		
		
        //Verificando a validacao dos dados de entrada feita automaticamente pelo Hibernate, com base nas anotacoes feitas na classe "EmpresaDto".
		if ( resultadoDaValidacao.hasErrors() ) {
			
			
			//Preparando o objeto de resposta padronizada que criei.
			ResponsePadronizado<EmpresaDto> responsePadronizado = new ResponsePadronizado<EmpresaDto>();
			
			
			//A variavel "resultadoDaValidacao" eh enviado pela validacao que o Spring fez, baseado nas anotacoes de validacao que estao la na classe "EmpresaDto".
			//Entao, pego a lista de erros dessa variavel.
			List<ObjectError> listaDeErros = resultadoDaValidacao.getAllErrors();
			
			
			for( ObjectError auxiliar : listaDeErros  ){
				
				//Pego a mensagem de erro da posicao atual.
				String mensagemDeErroExtraida = auxiliar.getDefaultMessage();
						
				responsePadronizado.getErrors().add(mensagemDeErroExtraida);
			}
			
			
			
			/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo badRequest(), ja deixa esse objeto com status code +400-Bad Request.
			 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
			 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
			*/
			return ResponseEntity.badRequest().body( responsePadronizado );
		}
		
		
		
		
		//Simulando uma alteracao no dto.
		empresaDtoRecebida.setId(300L);
		empresaDtoRecebida.setRazaoSocial("Teste de alteração");	
		empresaDtoRecebida.setCnpj("99999");

		
		//Preparando o objeto de resposta padronizada que criei.
		ResponsePadronizado<EmpresaDto> responsePadronizado = new ResponsePadronizado<EmpresaDto>();
		
		//Aqui eu coloco o objeto que quero de fato retornar, que eh o "empresaDtoRecebida", dentro dentro do objeto "responsePadronizado".
		responsePadronizado.setConteudoDoResponse( empresaDtoRecebida );
		
		
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
		*/
		return ResponseEntity.ok().body(responsePadronizado);
	}
	
	
}