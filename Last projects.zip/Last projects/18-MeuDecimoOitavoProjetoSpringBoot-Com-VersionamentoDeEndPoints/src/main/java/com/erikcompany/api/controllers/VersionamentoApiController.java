package com.erikcompany.api.controllers;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController           //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping("/api")   //Anotacao do Spring que uso para definir qual sera o caminho do endpoint.
public class VersionamentoApiController {

	
	
	
	
	                                      //Versionamento de API pela url, define versão 'v1'.
	                                      //@GetMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@PostMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	                                      //{nome}       -> Definindo um atributo que recebo atraves da url da requisicao.
	@GetMapping(value = "/v1/ola/{nome}") 
	public ResponseEntity<String> olaNomeV1( @PathVariable("nome") String nomeRecebido) {
		
		
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta.
		*/
		return ResponseEntity.ok().body("API versao v1 - Parametro recebido: " +nomeRecebido );
	}

	
	
                                           //Versionamento de API pela url, define versão 'v2'.
	                                       //@GetMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@PostMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	                                       //{nome}       -> Definindo um atributo que recebo atraves da url da requisicao.
	@GetMapping(value = "/v2/ola/{nome}")
	public ResponseEntity<String> olaNomeV2( @PathVariable("nome") String nomeRecebido ) {

		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta.
		*/		
		return ResponseEntity.ok().body("API versao v2 - Parametro recebido: " +nomeRecebido );
	}

	
	
	
	
	
	
	
	
	

											//Versionamento de API pelo Header 'X-API-Version', define versão 'v1'.
    										//@GetMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@PostMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
    										//{nome}       -> Definindo um atributo que recebo atraves da url da requisicao.
	                                        //headers      -> Definindo os parametros tem que me passar no header da requisicao para esse endpoint.
	@GetMapping(value = "/ola/{nome}", headers = "X-API-Version=v1")
	public ResponseEntity<String> olaNomeHeaderV1( @PathVariable("nome") String nomeRecebido ) {
		

		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta.
		*/		
		return ResponseEntity.ok().body("API com Header versao v1 - Parametro recebido: " +nomeRecebido );
	}

	
	

											//Versionamento de API pelo Header 'X-API-Version', define versão 'v2'.
    										//@GetMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@PostMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
											//{nome}       -> Definindo um atributo que recebo atraves da url da requisicao.
                                            //headers      -> Definindo os parametros tem que me passar no header da requisicao para esse endpoint. 
	@GetMapping(value = "/ola/{nome}", headers = "X-API-Version=v2")
	public ResponseEntity<String> olaNomeHeaderV2( @PathVariable("nome") String nomeRecebido ) {
		
		
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta.
		*/		
		return ResponseEntity.ok().body("API com Header versao v2 - Parametro recebido: " +nomeRecebido );
	}

}