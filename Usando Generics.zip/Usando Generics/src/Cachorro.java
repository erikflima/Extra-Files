public class Cachorro extends Animal implements Comparable {

	
    @Override
    public void consulta() {
    	
        System.out.println("Consultando cachorro.");
    }

    
    @Override
    public int compareTo(Object o) {
    	
        return 0;
    }
    
}