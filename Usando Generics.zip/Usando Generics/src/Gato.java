public class Gato extends Animal {

    @Override
    public void consulta() {
    	
        System.out.println("Consultando gato.");
    }
}