import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


//Objetivo desse programa eh mostrar metodos que recebem listas de forma generica.
//Ou seja, usando o simbolo "?", que significa "Generics".
public class TesteMetodosQueRecebemObjetosGenerics {
	
	
    public static void main(String[] args) {
    	
    	
        //Cria duas listas
        List<Cachorro> cachorroList = new ArrayList<>();
        List<Gato>     gatoList     = new ArrayList<>();
        
        //Preencho as listas
        cachorroList.add( new Cachorro() );
        gatoList.add( new Gato() );

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        //-----------Agora vou testar a chamadas dos metodos que tem o simbolo de interrogacao, que eh chamado de "Generics"

        
        SO FALTOU CHAMAR OS METODOS ABAIXO!!!!!
        E tambem atualizar a planilha com uma linha nova explicando sobre generics
    }
    
    

    
    
    
    
    
    
    
    
    
    
    
    //Metodo que recebe uma lista do tipo "Gato".
    public static void recebeListaDeGatos( List<Gato> listaDoTipoGato ) {
    	
        for ( Gato auxiliar : listaDoTipoGato ) {
        	
        	auxiliar.consulta();
        }
    }
    
    
    
    //Metodo que recebe uma lista do tipo "Gato".
    public static void recebeListaDeCachorros( List<Cachorro> listaDoTipoCachorro ) {
    	
        for (Cachorro auxiliar : listaDoTipoCachorro) {
        	
        	auxiliar.consulta();
        }
    }
    
    
    
    /*Metodo que recebe um objeto "List" de "uma classe qualquer", que obrigatoriamente estenda de "Animal".
      Ou seja, nessa caso, esse metodo pode receber uma lista de "Cachorro" ou uma lista de "Gato". Pois ambos extends de "Animal". */
    public static void recebeListaDeAnimais( List<? extends Animal> listaDeAnimais ){
    	
        for( Animal auxiliar : listaDeAnimais ) {
        	
        	auxiliar.consulta();
        }
    }
     
    
    
    /*Metodo que recebe um objeto "List" de "Cachorro", ou recebe uma "List" da classe pai de "Cachorro", que eh a classe "Animal".
      Ou seja, aqui nesse metodo, posso receber uma lista de "Cachorro" ou uma lista de "Animal". */    
    public static void recebeListaDeCachorroOuAnimal( List<? super Cachorro> listaDeCachorrosOuAnimal ){
    	
        Cachorro c1 = new Cachorro();        
        listaDeCachorrosOuAnimal.add( c1 );
        
        System.out.println("\nRecebe uma lista De Cachorro Ou Animal!");
        
    }

    
    
	  /*Metodo que recebe um objeto "List" de "uma classe qualquer", que obrigatoriamente implementa "Comparable".
	    Ou seja, nessa caso, esse metodo pode receber qualquer lista que implements a classe Comparable. */
	  public static void recebeListaDeSeilaOq( List<? extends Comparable> listaDeSeilaOque ){
	  	
	  	
	  	//Aqui eu mando ordenar a lista. Lembrando que essa ordenacao eh feita usando o metodo "compareTo()".
	      Collections.sort( listaDeSeilaOque );
	      System.out.println("\nOrdenenou a lista de seila o que!");
	  }     


}