package pacote1;

public class Carro {

	public Carro() {
		
		String nome = "Carro do Erik";
	}

}
