package pacote1;
import java.util.ArrayList;
import java.util.List;


public class GenericsTest {
	
	
	
    public static void main(String[] args) {

        List lista = new ArrayList(); // Criando uma lista que aceita objetos de qualquer tipo.
        
        lista.add("Erik");        //Adicionando uma String.
        lista.add(100L);          //Adicionando um Long.
        lista.add( new Carro() ); //Adicionando um objeto do tipo que inventei.

        
       
        for ( Object auxiliar : lista ) {
        	
            System.out.println(auxiliar);
        }

        
        for ( Object auxiliar : lista ) {
        	
        	
        	if (auxiliar instanceof String) {
        		
        		System.out.println("O conteudo dessa posicao da lista eh do tipo String:  ");	
        	}   
        	
        	
        	if (auxiliar instanceof Carro) {
        			
        		System.out.println("O conteudo dessa posicao da lista eh do tipo String:  ");	
        	}        	
        	

        	if (auxiliar instanceof Long) {
    			
        		System.out.println("O conteudo dessa posicao da lista eh do tipo String:  ");	
        	}    
        	
        }//for



    }//main
    
}//class