package com.erikcompany.api.controllers;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController                                                    //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping(value="/api/exemplo", produces="application/text") //Anotacao do Spring que uso para definir qual sera o caminho do endpoint. Digo que produso texto.
public class ExemploController {

	
	                                                           
	                                                            //@GetMapping -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@PostMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".                                     
	@GetMapping(value = "/{nome}")                              //Definindo um atributo que recebo atraves da url da requisicao.
	@PreAuthorize("hasAnyRole('ADMIN')")                        //
	public String exemplo( @PathVariable("nome") String nomeRecebido) {
		
		
		System.out.println("\n\n Entrando no metodo 'exemplo()' da classe 'ExemploController' ");


		return "Olá - Parametro recebido: " +nomeRecebido;
	}
	
}