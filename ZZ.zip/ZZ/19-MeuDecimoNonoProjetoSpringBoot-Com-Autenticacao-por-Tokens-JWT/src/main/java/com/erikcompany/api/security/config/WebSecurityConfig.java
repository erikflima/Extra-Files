package com.erikcompany.api.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.erikcompany.api.security.JwtAuthenticationEntryPoint;
import com.erikcompany.api.security.filters.JwtAuthenticationTokenFilter;

@Configuration                                                          //Anotacao do Spring, que diz para o Spring que essa eh uma classe de configuracao. Ou seja, uma classe que o Spring vai rodar internamente e fazer algo.
@EnableWebSecurity                                                      //
@EnableGlobalMethodSecurity(prePostEnabled = true)                      //
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {   //
	

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private JwtAuthenticationEntryPoint unauthorizedHandler;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private UserDetailsService userDetailsService;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	public void configureAuthentication( AuthenticationManagerBuilder authenticationManagerBuilder ) throws Exception {
		
		authenticationManagerBuilder.userDetailsService(this.userDetailsService).passwordEncoder(passwordEncoder() );
	}

	
	
	
	
	@Bean    // Anotação utilizada em cima dos métodos de uma classe, geralmente marcada com @Configuration, indicando que o Spring sozinho deve invocar esse metodo e gerenciar o objeto retornado por ele. Quando digo gerenciar é que agora este objeto pode ser injetado em qualquer ponto da sua aplicação.
	public PasswordEncoder passwordEncoder() {
		
		
		return new BCryptPasswordEncoder();
	}

	
	
	@Bean    // Anotação utilizada em cima dos métodos de uma classe, geralmente marcada com @Configuration, indicando que o Spring sozinho deve invocar esse metodo e gerenciar o objeto retornado por ele. Quando digo gerenciar é que agora este objeto pode ser injetado em qualquer ponto da sua aplicação.
	public JwtAuthenticationTokenFilter authenticationTokenFilterBean() throws Exception {
		
		JwtAuthenticationTokenFilter jwtAuthenticationTokenFilter = new JwtAuthenticationTokenFilter();
		
		
		return jwtAuthenticationTokenFilter;
	}

	
	
	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		
		
		httpSecurity.csrf()
		            .disable()
		            .exceptionHandling()
		            .authenticationEntryPoint(unauthorizedHandler)
		            .and()
				    .sessionManagement()
				    .sessionCreationPolicy( SessionCreationPolicy.STATELESS )
				    .and()
				    .authorizeRequests()
				    .antMatchers("/auth/**")
				    .permitAll()
				    .anyRequest()
				    .authenticated();
		
		
		httpSecurity.addFilterBefore( authenticationTokenFilterBean(), 
				                      UsernamePasswordAuthenticationFilter.class);
		
		
		httpSecurity.headers().cacheControl();
	}

}