package com.erikcompany.api.security.controllers;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erikcompany.api.response.Response;
import com.erikcompany.api.security.dto.JwtAuthenticationDto;
import com.erikcompany.api.security.dto.TokenDto;
import com.erikcompany.api.security.utils.JwtTokenUtil;


@RestController                           //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping("/auth")                  //Anotacao do Spring que uso para definir qual sera o caminho do endpoint.
@CrossOrigin(origins = "*")               //
public class AuthenticationController {
	
	

	private static final Logger log           = LoggerFactory.getLogger(AuthenticationController.class);
	private static final String TOKEN_HEADER  = "Authorization";
	private static final String BEARER_PREFIX = "Bearer ";

	
	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private AuthenticationManager authenticationManager;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private JwtTokenUtil jwtTokenUtil;

	
	@Autowired //Anotacao do Spring que faz o Spring injete(crie) um objeto.
	private UserDetailsService userDetailsService;

	
	
	
	               //Metodo que gera e retorna um novo token JWT.
	               //@PostMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@GetMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
                   //@RequestBody  -> Essa anotacao faz com que ao receber a requisicao, o que estiver no body da requisicao vai ser jogado dentro do objeto "empresaDtoRecebida", pra que eu posso manipular esse objeto depois. 
                   //@Valid        -> Faz com que o parametro seja validado automaticamente pelo hibernate validator(que sao anotacoes), baseado nas anotacoes de validacao que estao na classe do paramentro.
                   //BindingResult -> Trabalha junto com a anotacao @Valid. Se o hibernate validator(que sao anotacoes) realizar as validacoes e achar algum erro, ele vai se encarregar de me passar um objeto "BindingResult" ai dentro do metodo. Se nao tiver nenhum erro, o objeto "BindingResult" fica vazio.
	@PostMapping   
	public ResponseEntity<Response<TokenDto>> gerarTokenJwt( @Valid @RequestBody JwtAuthenticationDto authenticationDto,
			                                                                     BindingResult        result            ) throws AuthenticationException {
		
		
		
		
		Response<TokenDto> response = new Response<TokenDto>();

		
		if (result.hasErrors()) {
			
			log.error("Erro validando lançamento: {}", result.getAllErrors());
			
			result.getAllErrors().forEach(error -> response.getErrors().add( error.getDefaultMessage()) );
	
			
			
			/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo badRequest(), ja deixa esse objeto com status code +400-Bad Request.
			 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
			 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
			*/			
			return ResponseEntity.badRequest().body(response);
			
		}

		
		log.info("Gerando token para o email {}.", authenticationDto.getEmail() );
		
		
		
		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken( authenticationDto.getEmail(), authenticationDto.getSenha() );
		
		Authentication authentication = authenticationManager.authenticate(	usernamePasswordAuthenticationToken );
		
		
		SecurityContextHolder.getContext().setAuthentication(authentication);

		UserDetails userDetails = userDetailsService.loadUserByUsername( authenticationDto.getEmail() );
		
		String token = jwtTokenUtil.obterToken(userDetails);
		
		
		TokenDto tokenDto = new TokenDto(token);
		
		response.setConteudoDoResponse(tokenDto);

		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
		*/
		return ResponseEntity.ok().body(response);		
	}

	
	
	
	                                     //Gera um novo token com uma nova data de expiração.
	                                     //@PostMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@GetMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	@PostMapping(value = "/refresh")     
	public ResponseEntity< Response<TokenDto> > gerarRefreshTokenJwt( HttpServletRequest request ) {
		
		
		
		log.info("Gerando refresh token JWT.");
		
		Response<TokenDto> response = new Response<TokenDto>();
		
		Optional<String> token = Optional.ofNullable( request.getHeader(TOKEN_HEADER) );

		
		
		
		if ( token.isPresent() && token.get().startsWith(BEARER_PREFIX) ) {
			
			token = Optional.of( token.get().substring(7) );
		}

		
		
		if ( !token.isPresent() ) {
			
			response.getErrors().add("Token não informado.");
			
			
		} else if ( !jwtTokenUtil.tokenValido(token.get() ) ) {
			
			response.getErrors().add("Token inválido ou expirado.");
		}

		
		
		if ( !response.getErrors().isEmpty() ){

			
			/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo badRequest(), ja deixa esse objeto com status code +400-Bad Request.
			 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
			 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
			*/				
			return ResponseEntity.badRequest().body(response);
			
		}

		
		
		String refreshedToken = jwtTokenUtil.refreshToken( token.get() );
		
		TokenDto tokenDto = new TokenDto( refreshedToken );
		
		response.setConteudoDoResponse( tokenDto );

		
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta. Ai o Spring vai transformar esse objeto "ResponseEntity" em um json e retornar.
		*/
		return ResponseEntity.ok().body(response);	
		
		
	}

}