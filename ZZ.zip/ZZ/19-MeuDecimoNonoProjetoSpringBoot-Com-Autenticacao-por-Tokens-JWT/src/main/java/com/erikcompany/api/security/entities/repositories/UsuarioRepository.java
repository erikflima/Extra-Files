package com.erikcompany.api.security.entities.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.erikcompany.api.security.entities.Usuario;





/*
O que eu quero eh criar um objeto que tenha metodos que acessa uma tabela no meu banco de dados, blz!
Entao eu crio uma interface, que herda "JpaRepository" da biblioteca Hibernate-JPA.
Essa "JpaRepository" obriga o herdador a implementar um monte de metodos. 
Eh tipo um esqueminha, pq que vai implementar esse monte de metodos, eh o Spring, quando eu usar a anotacao "@Autowired" em alguma parte do codigo.

   Obs: -> JpaRepository<Classe da tabela que quero me conectar, Tipo da chave primaria da tabela> 
*/
@Transactional(readOnly = true)                                        
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
	
	
	
	
	/*Metodos de implementacao obrigatoria que quero criar.
	   O fato de eu dar o nome do metodo como "findBy...", "readBy...", ou "getBy..." ja faz o Spring entender, que no momento que eu 
	   for injetar um objeto "UsuarioRepository" com a anotacao "@Autowired", a implementacao automatica desse
	   metodo vai ser assim:"select * from USUARIO where email = emailRecebidoPorParametro".
	   Bem foda ne! Na duvida consultar -> http://blog.algaworks.com/spring-data-jpa/
	*/	
	public Usuario findByEmail( String emailRecebidoPorParametro );


}