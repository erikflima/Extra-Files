package com.erikcompany.api.security.services;
import java.util.Optional;

import com.erikcompany.api.security.entities.Usuario;



public interface UsuarioService {

	
	//Busca e retorna um usuário dado um email.
	Optional<Usuario> buscarPorEmail(String email);

}