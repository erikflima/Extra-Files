package com.erikcompany.api.security.utils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


//Classe utilizada para criptografar, descriptografar e validar senhas.
public class SenhaUtils {

		
	
	
	//Recebe uma senha sem criptografia e retorna a mesma senha criptofrada em formato hash.
	public static String gerarBCrypt(String senhaRecebidaSemCriptografia) {
		
		
		if (senhaRecebidaSemCriptografia == null) {
		
			return senhaRecebidaSemCriptografia;
	}

		//Objeto que serve para fazer criptografia.
		BCryptPasswordEncoder bCryptEncoder = new BCryptPasswordEncoder();
		
		//Criptografando a senha e transformando ela em um hash.
		String senhaCriptografadaEmFormatoHash = bCryptEncoder.encode(senhaRecebidaSemCriptografia);
		
		
		return senhaCriptografadaEmFormatoHash;
	}

	
	
	
	//Verifica se a senha é válida.
	public static boolean senhaValida(String senhaSemCriptografia, String senhaCriptografada) {
		
		
		//Objeto que serve para fazer a descriptografia.
		BCryptPasswordEncoder bCryptEncoder = new BCryptPasswordEncoder();
		
		
		//Verifico se a "senhaSemCriptografia" eh igual a "senhaCriptografada"
		boolean respostaDaValidacao = bCryptEncoder.matches( senhaSemCriptografia, senhaCriptografada );
		
		return respostaDaValidacao;
	}

	
}//class