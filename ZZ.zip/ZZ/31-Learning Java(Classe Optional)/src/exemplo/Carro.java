package exemplo;

public class Carro {

	
	int  ano = 100;
	Pneu pneu;


	public Carro(){
	}
	

	//----------Getters and Setters----------//
	public int getAno() {
		
		return ano;
	}

	public void setAno(int ano) {
		
		this.ano = ano;
	}	
	
	
	public Pneu getPneu() {
		return pneu;
	}

	public void setPneu(Pneu pneu) {
		this.pneu = pneu;
	}	
}