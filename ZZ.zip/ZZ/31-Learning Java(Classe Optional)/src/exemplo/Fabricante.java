package exemplo;

public class Fabricante{

	String nome;
	
	public Fabricante() {
	}
	
	
	//----------Getters and Setters----------//	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}