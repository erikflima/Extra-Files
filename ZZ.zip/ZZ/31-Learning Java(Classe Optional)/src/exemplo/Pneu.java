package exemplo;

public class Pneu{

	
	String     descricao;
	Fabricante fabricante;	
	
	
	public Pneu(){	
	}	

	
	//----------Getters and Setters----------//		
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	
	public Fabricante getFabricante() {
		return fabricante;
	}

	public void setFabricante(Fabricante fabricante) {
		this.fabricante = fabricante;
	}
	
}