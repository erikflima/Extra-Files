package exemplo;
import java.util.Optional;

public class TesteUsandoOptional {

    //Video com mais detalhes -> https://www.youtube.com/watch?v=09YzkTIpak4&t=616s
	
	/*---O Objetivo aqui eh evitar o nullPointer Exception.---*/
	public static void main(String[] args) {
		

        Carro carro = null;
   
        
        
        //1� Jeito de evitar um nullPointer.
		//Aqui eu tento pegar ou setar o valor, o que resultaria em um nullPointer Exception. Mas fiz o if e evitei um possivel nullpointer.
		if ( carro != null ) {
			
	        carro.setAno(500);
			int valorExtraido1 = carro.getAno();
			
			System.out.println("Exemplo 1 - Utilizando if: " +valorExtraido1);
		}
		else {
			System.out.println("Exemplo 1 - Utilizando if: Nao deu para extrair o ano.");
			
		}
		
		

		//-------------------------------------------------------------
		
		
		
        //2� Jeito de evitar um nullPointer. 
		//Aqui eu crio um objeto "Optional", e jogo o objeto "carro" dentro dele. O carro pode estar nullo ou nao, mas mesmo assim eu jogo ele dentro dentro do "Optional".
		Optional<Carro> carroOptional = Optional.ofNullable(carro);
	
		
		//Tento extrair o valor do atributo "ano". Se a variavel "carro" estiver nulla, entao o retorno vai ser 500. Legal ne! Mas pratico do que o if.
        int valorExtraido2 = carroOptional.map( Carro::getAno ).orElse(500);
        
        
		System.out.println("Exemplo 2 - Utilizando Optional: " +valorExtraido2);
		
		
		
		//-------------------------------------------------------------		

        
		
        //3� Jeito de evitar um nullPointer. 
		
		
		//Aqui eu crio um objeto "Optional", e jogo o objeto "carro" dentro dele. O carro pode estar nullo ou nao, mas mesmo assim eu jogo ele dentro dentro do "Optional".
		Optional<Carro> carroOptional3 = Optional.ofNullable(carro);
	
		
		//Tento extrair o valor do atributo "nome" do objeto Fabricante.. Se a variavel "carro" estiver nulla, entao o retorno vai ser o texto que defini. Legal ne! Mas pratico do que varios if's.
		//Se algum get retornar "null", entao o nullPoint exception nao ocorre, eh e retornado o que eu coloquei na condicao "orElse". Daora.
		String valorExtraido3 = carroOptional3.map(Carro::getPneu     )
		                                      .map(Pneu::getFabricante)	
		                                      .map(Fabricante::getNome)
				                              .orElse("Nao deu para extrair o nome de fabricante.");
          
		System.out.println("Exemplo 3 - Utilizando Optional: " +valorExtraido3);

		
	}

}