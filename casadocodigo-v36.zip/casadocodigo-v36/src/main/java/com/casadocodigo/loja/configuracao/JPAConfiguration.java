package com.casadocodigo.loja.configuracao;
import java.util.Properties;
import javax.sql.DataSource;
import javax.persistence.EntityManagerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;


                             //Classe responsavel pelas configuracoes para usar JPA. E eh chamado pelo Spring.
@EnableTransactionManagement //Anotacao que diz ao Spring que essa eh uma classe de configuracao de uso do JPA, e que ocorrera transacoes com banco de dados com essa configuracao.
public class JPAConfiguration {

	
	@Bean //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public LocalContainerEntityManagerFactoryBean entityManagerFactory( DataSource dataSource ) { // O Sring vai me passar o parametro "dataSource", que pode vir do metodo "criaUmDataSource()" que esta nessa classe ou "dataSource()" da classe "DataSourceConfigurationTest" que criei.
		
		
		//Criando um obj tipo "LocalContainerEntityManagerFactoryBean", que eh responsavel por conter as configuracoes para utilizar o Hibernate.
		//Depois de setar as configuracoes, eu passo ele para o Spring
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();

		
		//Diz qual Implementação do JPA e biblioteca ORM que vou usar, nesse caso caso a biblioteca usada vai ser o Hibernate
		JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	
		

		
		
		//Configurações específicas do Hibernate
		Properties props = new Properties();
		props.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect"); //Dizendo qual dialeto sql(padrao de comandos SQL, pois cada banco tem suas diferenciacoes) que vai ser usado
		props.setProperty("hibernate.show_sql", "true");                               //Mostra as queries executas pelo Hibernate no console do Eclipse
		props.setProperty("hibernate.hbm2ddl.auto", "update");                         //Permite que o Hibernate crie as tabelas baseadas nos meus objetos caso elas não existam
		props.setProperty("hibernate.format_sql", "true");                             //Formata com quebra de linhas a saida que aparece no Console do Eclipse


		
		factory.setJpaVendorAdapter(vendorAdapter);                //Adicionando o objeto
		factory.setDataSource(dataSource );                         //Adicionando o objeto  
		factory.setJpaProperties(props);                           //Adicionando o objeto
		factory.setPackagesToScan("com.casadocodigo.loja.models"); //Digo onde estao os modelos de objetos
		
		
		//Retornar para o Spring
		return factory;		
		
	}//entityManagerFactory


	

	
//Metodo que eu mesmo criei para auxiliar so para criar um objeto DriverManagerDataSource que tem algumas informacoes do banco
	@Bean                                  //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	@Profile("banco_de_desenvolvimento")   //Aqui eu coloco o nome que quero dar para esse profile. Ai depois posso usar esse nome.
	public DataSource criaUmDataSource(){
		
		//Diz os dados de acesso ao banco - Propriedades JDBC
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		
		dataSource.setUsername("root");                                //User do banco
		dataSource.setPassword("breaks");                              //Senha do banco
		dataSource.setUrl("jdbc:mysql://localhost:3306/casadocodigo"); //Nome do banco do esquema que estou chamando de "casadocodigo"
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		
		return dataSource;

	}//criaUmDataSource


	
	
	
	
	      //Esse metodo eh chamado pelo Spring. E retorna um objeto do tipo "JpaTransactionManager", que eh um objeto que o Spring precisa para manusear as criar e manusear as transacoes com JPA.
	@Bean //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public JpaTransactionManager transactionManager( EntityManagerFactory emf) {
		
		
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager(emf); 
		
		//Retorna para o Spring
		return jpaTransactionManager;

		
	}//transactionManager
	
	
	
	
	

}//class
