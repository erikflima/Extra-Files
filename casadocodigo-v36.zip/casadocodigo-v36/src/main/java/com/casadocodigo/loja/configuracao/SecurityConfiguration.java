package com.casadocodigo.loja.configuracao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;



//@EnableWebSecurity  //Anotacao versao nova   que vem da biblioteca spring-security-config versoes novas,     que diz que essa classe vai ser a classe de configuracao do Spring Security.                              
@EnableWebMvcSecurity //Anotacao versao antiga que vem da biblioteca spring-security-config versao "4.0.0.M2", que diz que essa classe vai ser a classe de configuracao do Spring Security.
public class SecurityConfiguration extends WebSecurityConfigurerAdapter{ //WebSecurityConfigurerAdapter  Eh uma extensao para configurar algumas coisas de acesso do Spring Secutity
	
	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo UsuarioDao
	private UserDetailsService usuarioDao;


	
	
	
	/*Metodo chamado pelo Spring, e que serve para definir o que podera e o que nao podera ser acessado sem realizar o login.*/
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		//O objeto http eu recebo do Spring.
		//Metodo para definir o que pode e o que nao pode ser acessado sem antes passar pelo o login. 
		//"ADMIN" so o nome que escolhi para esse perfil de permissao. Mas eu posso colocar qualquer nome e/ou criar mais perfis de permissoes. Mas quando for na tabela "Role" vai ficar como "ROLE_ADMIN". Pq eh um padrao do Spring.
		http.authorizeRequests().antMatchers("/produtos/form").hasRole("ADMIN")                               //Bloquear a url "/produtos/form".
		                        .antMatchers("/carrinho/**").permitAll()                                      //Permitir o acesso a url "/carrinho/", e tambem urls que vem depois da "/", por exemplo "/carrinho/algumaCoisa".
		                        .antMatchers(HttpMethod.POST, "/produtos").hasRole("ADMIN")                   //Bloquear o acesso  via POST para a url "/produtos"
		                      //.antMatchers(HttpMethod.GET,  "/produtos").permitAll()                        //Permitir o acesso  via GET  para a url "/produtos" 
		                        .antMatchers(HttpMethod.GET,  "/produtos").hasRole("ADMIN")                   //Bloquear o acesso  via GET  para a url "/produtos", e tambem urls que vem depois da "/", por exemplo "/produtos/algumaCoisa".
		                        .antMatchers("/produtos/**").permitAll()                                      //Permitir o acesso a url "/produtos/", e tambem urls que vem depois da "/", por exemplo "/produtos/algumaCoisa".
		                        .antMatchers("/resources/**").permitAll()                                     //Permitir o acesso aos arquivos CSS, Font e JavaScript que estao na pasta "resources" do projeto 
		                        .antMatchers("/").permitAll()                                                 //Permitir o acesso a url "/".
		                        .anyRequest().authenticated()                                                 //Digo que todas as requisicoes devem passar por essas verificacoes que fiz.
		                      //.and().formLogin();                                                           //Se o usuario nao estiver logado, e tentar acessar uma url protegida, entao mando para a tela de login. OBS: Eu nao criei a tela do "login", eu simplemente chamo o metodo "formLogin()", ai o Spring me retorna uma tela pronta de login.
		                        .and().formLogin().loginPage("/login").permitAll()                            //Se o usuario nao estiver logado, e tentar acessar uma url protegida, entao mando para a tela de login que eu criei.
		                        .and().logout().logoutRequestMatcher( new AntPathRequestMatcher("/logout") ); //Aqui eu defino qual vai ser a url para efetuar o logout, e nesse caso eu coloquei "/logout". Eh bom lembrar que o Spring Secutity faz os procedimentos de logout sozinho e eu nao preciso implementar nada.
	}//configure-1

	

	/*Metodo chamado pelo Spring, que serve para carregar dizer as permissoes(roles) */
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		
		//Dizendo para o Spring Security que o objeto "usuarioDao" vai ser o resposavel por executar um metodo que vai realizar a validacao do dados digitados no formulario da pagina.
		auth.userDetailsService(usuarioDao)
		.passwordEncoder( new BCryptPasswordEncoder() );  //Aqui eu uso o metodo "passwordEncoder()", que adiciona cryptografia no campo senha. O parametro que passo eh uma instacia da classe "BCryptPasswordEncoder", essa instancia eh um padrao de criptografia do Spring, e o Spring ja sabe trabalhar com essa forma. Mas eu poderia usar outro esquema de criptografia, como por exemplo "SH256", "SH512", "MD5" e por ai vai 
		       
		
	}//configure-2

	
	
	
	
}//class




