package com.casadocodigo.loja.configuracao;
import javax.servlet.Filter;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletRegistration.Dynamic;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;


//1)Ao iniciar a aplicao, essa classe eh chamada pelo Spring
//  Entao o Spring chama os metodos dessa classe para configurar os Controllers do projeto(Lembrando que Controllers sao classes java que recebem requisicoes http.)
public class ServletSpringMVC extends AbstractAnnotationConfigDispatcherServletInitializer{
	                                 
	
	/*1°-Primeiro metodo chamado pelo Spring
	   Esse metodo vai retornar para o Spring o nome da classes que tem algumas configuracoes que eu mesmo fiz, para que o projeto funcione.
	   essas configuracoes sao:
	   
	     - Nenhuma por enquanto	
	*/
	@Override 
	protected Class<?>[] getServletConfigClasses() {
		
		//Por enquanto retornando vazio.
		return new Class[] {};
	}
	
	
	

	/*1.2°- Metodo chamado pelo Spring
	 Esse metodo carrega eh executado logo ao iniciar a aplicacao, e ele vai retornar para o Spring um array de nomes das classes que tem algumas configuracoes que eu mesmo fiz, para que o projeto funcione.
	 Essas classes de configuracoes sao:


	   AppWebConfiguration.class   -> Que informa algumas configuracoes para o Spring.  
	                                  O nome do pacote em que estao os Controllers desse projeto. Obs: O nome esta sendo apontado dentro da anotacao "@ComponentScan". 
	                                  O endereco da pasta que contem as paginas JSP do projeto. 
	                                  O sufixo (.jsp) que nao precisa ser digitado pelo usuario na url das requisicoes
	   JPAConfiguration.class      -> Que informa algumas configuracoes que fiz para usar JPA.
	   SecurityConfiguration.class -> Pra que o Spring reconheca a classe "SecurityConfiguration" que criei, para que o esquema do Spring Security funcione.
    */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		

		//Retornando as classe "AppWebConfiguration", "JPAConfiguration", "SecurityConfiguration".
		return new Class[]{AppWebConfiguration.class, JPAConfiguration.class, SecurityConfiguration.class};
	}
	
	
	
	
	
	
	/*2°-Segundo metodo chamado pelo Spring
	Aqui eu digo para o Spring que o Controller(Servlet) do meu projeto vai atender requisicoes apartir da url "/", ou seja "http://localhost:8080/casadocodigo-v1/". */
	@Override 
	protected String[] getServletMappings() {
		
		//URL base que o Controller(Servlet) vai responder
		return new String[] {"/"};
	}


	
	/*3°-Terceiro metodo chamado pelo Spring
	Aqui eu defino alguns filtros(Opcao do Spring) que quero que o Spring use.*/
	@Override
	protected Filter[] getServletFilters() {

		
		/*Criando um objeto do tipo "CharacterEncodingFilter", esse objeto serve para guardar qual configuracao de enconding 
		eu que nas paginas(views) que o Spring devolve para o usuario final. */
		CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
		
		//Defino que todas as paginas(views) do projeto vao usar o padrao de acentuacao "UTF-8". Lembrando que esse padrao eh universal
		encodingFilter.setEncoding("UTF-8");
		
		
		//Retornando um Array de "Filter".
		return new Filter[] {encodingFilter} ;
	}
	
	
	

	
	
	//Nao sei a ordem°- metodo chamado pelo Spring
	// Metodo de sobreescrita obrigatoria caso esteja a aplicacao suporte upload de arquvivos
	@Override
	protected void customizeRegistration(Dynamic registration) {

		//Criando um objeto "MultipartConfigElement", e digo que nao vou querer fazer nenhuma mudanca nos arquivos recebidos, por isso deixo apenas "".
		//Ou seja,dizendo para a aplicacao "Receba o arquivo cru, do jeito que veio e nao facao nenhuma modificacao nele.
		MultipartConfigElement multipartConfigElement = new MultipartConfigElement("");
		
		registration.setMultipartConfig( multipartConfigElement );
	}
	
	
	
	


}
