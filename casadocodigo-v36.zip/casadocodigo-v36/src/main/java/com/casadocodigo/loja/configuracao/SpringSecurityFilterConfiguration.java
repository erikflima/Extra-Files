package com.casadocodigo.loja.configuracao;
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

//Classe que vai ser responsavel pela inicializacao do filtro de seguranca do Spring
public class SpringSecurityFilterConfiguration extends AbstractSecurityWebApplicationInitializer{

	
}//class


