package com.casadocodigo.loja.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import com.casadocodigo.loja.daos.ProdutoDAO;
import com.casadocodigo.loja.models.CarrinhoCompras;
import com.casadocodigo.loja.models.CarrinhoItem;
import com.casadocodigo.loja.models.Produto;
import com.casadocodigo.loja.models.TipoPreco;



@Controller                                       //Anotacao que diz que essa classe vai ser um Controller do Spring (Ou seja, uma classe Servlet que recebe as requisições http)
@RequestMapping("/carrinho")                      //Dizendo que todos os metodos desse controller vao ter a uri com inicio "http://localhost:8080/casadocodigo-v8/produtos"
@Scope(value=WebApplicationContext.SCOPE_REQUEST) //Anotacao do Spring que defino o escopo da estancia desse controller. O escopo "SCOPE_REQUEST" diz para o Spring criar uma estancia desse controller a cada requisicao. Ou seja, a cada requisicao feita pelo usuario, o Spring cria uma estancia dessa classe, atende a requisicao devolvendo uma pagina, e por fim deleta a estancia dessa classe.
public class CarrinhoComprasController {
	
	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo ProdutoDAO
	private ProdutoDAO produtoDao;


	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo CarrinhoCompras
	private CarrinhoCompras carrinho;	
	
	
	

	@RequestMapping("/add") 
	public ModelAndView add( Integer produtoId, TipoPreco tipoPreco ) { 
		
		
		System.out.println("\n\nCarrinhoComprasController - Executando o metodo 'add()' ");
	
		
		CarrinhoItem carrinhoItem = criaItem( produtoId, tipoPreco );
		
		carrinho.add(carrinhoItem);
		
		
		/*
		Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		Defino para qual pagina vou retornar----->( pagina que vou retornar como resposta da requisicao ).
		
		 "redirect:produtos" -> Redirecionando a requisicao. 
		  Ou seja, redireciona a requisicao para a uri "http://localhost:8080/casadocodigo-v8/carrinho"  do tipo "GET"
		  que por conseguencia vai cair no metodo "itens()", que devolve a pagina "itens.jsp" 
		  Fazer o redirecionamento, evita que informações fiquem salvas na memoria do navegador */	 
		ModelAndView modelAndView = new ModelAndView("redirect:/carrinho");
			
		//Retornando o objeto modelAndView como resposta da requisicao.
		return modelAndView;
	}
	
	
	
	
	
	private CarrinhoItem criaItem ( Integer produtoId, TipoPreco tipoPreco ) {
		
		Produto produto = produtoDao.find( produtoId );
		
		CarrinhoItem carrinhoItem = new CarrinhoItem( produto, tipoPreco );
		
		return carrinhoItem;
	}
	
	
	
	
	/*Dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v14/carrinho", esse metodo sera responsavel por enviar uma resposta
    Tambem digo que esse metodo vai ser executado somente se a requisicao que o usuario fizer for do tipo "GET".
    */	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView itens(){
		

		//Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		//Defino para qual pagina vou retornar----->( nome pagina jsp que vou retornar como resposta da requisicao ).
		ModelAndView modelAndView = new ModelAndView("/carrinho/itens");

		//Retornando o objeto modelAndView como resposta da requisicao.
		return modelAndView;
	
	}


	
	
	@RequestMapping("/remover")
	public ModelAndView remover(Integer produtoId, TipoPreco tipoPreco){
		
		carrinho.remover( produtoId, tipoPreco );
	
				
		/*
		Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		Defino para qual pagina vou retornar----->( pagina que vou retornar como resposta da requisicao ).
		
		 "redirect:produtos" -> Redirecionando a requisicao. 
		  Ou seja, redireciona a requisicao para a uri "http://localhost:8080/casadocodigo-v8/carrinho"  do tipo "GET"
		  que por conseguencia vai cair no metodo "itens()", que devolve a pagina "itens.jsp" 
		  Fazer o redirecionamento, evita que informações fiquem salvas na memoria do navegador */	 
		ModelAndView modelAndView = new ModelAndView("redirect:/carrinho");
			
		//Retornando o objeto modelAndView como resposta da requisicao.
		return modelAndView;

	}

	
	
	
	

}//class                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     