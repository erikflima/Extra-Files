package com.casadocodigo.loja.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.casadocodigo.loja.daos.ProdutoDAO;
import com.casadocodigo.loja.models.Produto;

@Controller //Anotacao que diz que essa classe vai ser um Controller do Spring (Ou seja, uma classe Servlet que recebe as requisições http)
public class HomeController { 
	
	
	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo ProdutoDAO
	private ProdutoDAO produtoDao;
	
	
	
	
	
	
	
	
	@RequestMapping("/")                    //Dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v18/", esse metodo sera responsavel por enviar uma resposta
	@Cacheable(value="cachePaginaHomeJSP")  //Essa anotacao faz com que o Spring execute esse metodo de boa, ai ele pega o retorna e guarda na memoria, entao se o usuario pedir a pagina novamente, o Spring verifica se a pagina teve alguma alteracao, se teve, ai executa o metodo normalmente e faz a query no banco de dados, se nao, entao devolve a pagina que esta guardanda na memoria que foi construida na requisicao anterior. Fazendo esse esquema eu economizo recursos. O parametro value="nomeQueEQuiser" eh so um nome que dou para que fique como nome do cookie que vai ficar no navegador do cliente.
	public ModelAndView retornaHome() {

		
		System.out.println("\n\nHomeController - Executando o metodo 'retornaHome()' ");		

		
		//Pegando todas as linha da tabela "Produto" no db.
		List<Produto> produtos = produtoDao.listar();
		

		//Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		//Defino para qual pagina vou retornar----->( nome pagina jsp que vou retornar como resposta da requisicao ).
		ModelAndView modelAndView = new ModelAndView("home"); //home.jsp
		
		
		
		//Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
		//------------------->(chave de acesso, Objeto que quero vincular a pagina(view) ).		
		modelAndView.addObject("produtos", produtos);		
		
		//Retornando a pagina home.jsp
		return modelAndView;
		
	}//retornaHome

	
	
}//class
