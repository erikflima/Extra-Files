package com.casadocodigo.loja.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller //Anotacao que diz que essa classe vai ser um Controller do Spring (Ou seja, uma classe Servlet que recebe as requisições http)
public class LoginController {
	
	
	
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public ModelAndView loginForm(){
		
		
		System.out.println("\n\nLoginController - Executando o metodo 'loginForm()' ");	
		
		
		//Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		//Defino para qual pagina vou retornar----->( nome pagina jsp que vou retornar como resposta da requisicao ).
		ModelAndView modelAndView = new ModelAndView("loginFormulario"); //loginFormulario.jsp
	
		
		//Retornando a pagina home.jsp
		return modelAndView;

	}//loginForm
	
	
	
	
	@RequestMapping(value="/deslogar", method=RequestMethod.GET)
	public ModelAndView deslogar(){
		
		
		System.out.println("\n\nLoginController - Executando o metodo 'deslogar()' ");	
		
	
		//Aqui eu redireciono o usuario para a url "http://localhost:8080/casadocodigo-v1/logout", e com isso o Spring Security vai realizar o logout.
		//Lembrando que eu configurei a url de logout la no metodo "configure(HttpSecurity http)" la na classe "SecurityConfiguration".		
		ModelAndView modelAndView = new ModelAndView("redirect:/logout");
	
		
		//Retornando o objeto modelAndView como resposta da requisicao.
		return modelAndView;

	}//deslogar	
	
	
	
	
}//class
