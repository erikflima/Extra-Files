package com.casadocodigo.loja.controllers;
import java.util.concurrent.Callable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.casadocodigo.loja.models.CarrinhoCompras;
import com.casadocodigo.loja.models.DadosPagamento;



@Controller                   //Anotacao que diz que essa classe vai ser um Controller do Spring (Ou seja, uma classe Servlet que recebe as requisições http)
@RequestMapping("/pagamento") //Dizendo que todos os metodos desse controller vao ter a uri com inicio "http://localhost:8080/casadocodigo-v15/pagamento"
@Scope(value=WebApplicationContext.SCOPE_REQUEST) //Anotacao do Spring que defino o escopo da estancia desse controller. O escopo "SCOPE_REQUEST" diz para o Spring criar uma estancia desse controller a cada requisicao. Ou seja, a cada requisicao feita pelo usuario, o Spring cria uma estancia dessa classe, atende a requisicao devolvendo uma pagina, e por fim deleta a estancia dessa classe.
public class PagamentoFinalController {


	
	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo CarrinhoCompras
	CarrinhoCompras carrinho;
	

	@Autowired                  //Anotacao que faz o Spring injete(crie) um objeto do tipo RestTemplate
	RestTemplate restTemplate; //Esse objeto eh especial, entao nao basta so colocar a anotacao "@Autowired", tenho que tambem criar o metodo "restTemplate()" la na classe "AppWebConfiguration".

	
	
	
	
	
	/*
	 Obs: 
	 	@RequestMapping(method=RequestMethod.POST) ->  Anotacao dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v8/pagamento", esse metodo sera responsavel por enviar uma resposta.
                                                       Tambem digo que esse metodo vai ser executado somente se a requisicao que o usuario fizer for do tipo "POST".
		
		RedirectAttributes redirectAttributes -> Esse parametro eh enviado automaticamente pelo Spring, e eu so pego isso no paramtro do metodo se eu precisar. Referencia Curso: Curso Spring MVC I Criando aplicações web - Parte: 5-Redirect com Escopo de Flash-Video: 1
	*/	
	@RequestMapping(value="/finalizar", method=RequestMethod.POST)
	public ModelAndView finalizar( RedirectAttributes model ){
		

		
		System.out.println("\n\nPagamentoFinalizarController - Executando o metodo 'finalizar()' ");
		
		
		/*
		Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		Defino para qual pagina vou retornar----->( pagina que vou retornar como resposta da requisicao ).
		
		 "redirect:produtos" -> Redirecionando a requisicao. 
		  Ou seja, redireciona a requisicao para a uri "http://localhost:8080/casadocodigo-v16/produtos"  do tipo "GET"
		  que por conseguencia vai cair no metodo "listar()", que devolve a pagina "lista.jsp" 
		  Fazer o redirecionamento, evita que informações fiquem salvas na memoria do navegador, e assim o redirecionamento nao corre o risco de cair na uri "http://localhost:8080/casadocodigo-v16/produtos"  do tipo "POST"	*/	 
		ModelAndView modelAndView = new ModelAndView("redirect:/produtos");
		
		

		try {
			
			//Endereco do servico feito pela Alura, que recebe requisicao POST() e espera um  Json com o formato assim oh-> {"value":500} como parametro, e devolve uma String como reposta.
			String uri = "http://book-payment.herokuapp.com/payment";
			
			System.out.println("\n\nURI que vou fazer a requisicao: " +uri );
			


			
			/*Objeto do tipo "RestTemplate" eh do Spring, e serve para fazer qualquer tipo de requisicao.
		      Usando o metodo postForObject() para fazer um POST.
			  OBS: O estranho aqui, eh o que o Spring vai automaticamente pegar o meu parametro do tipo "DadosPagamento" e vai converter ele para uma String em formato JSON. Que vai ficar assim oh -> {"value":500}. Mas para que isso seja feito, eu preciso incluir alguma biblioteca de convercao de objetos para JSON, entao la no arquivo POM.xml, eu inclui as dependencias da biblioteca "jackson-core" e "jackson-databind".
			------------------------------------------->(Uri do servico que quero consumir, objeto que vou enviar como parametro, tipo de retorno que o servidor vai me devolver ) */
			String response = restTemplate.postForObject(uri, new DadosPagamento(carrinho.getTotal()), String.class);
			
			System.out.println("\n\nResposta que o webserice me retornou: " +response );
			

			/*
			 Esquema para adicionar objeto para caso for feito um redirecionamento de requisicao
			 Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
			----------------------------------->(chave de acesso, Objeto que quero vincular a pagina(view) ).
			*/
			model.addFlashAttribute("chaveMensagemDeSucesso", response);
			
				
			//Retornando o objeto modelAndView como resposta da requisicao.
			return modelAndView;			
			
			
			
		} catch( HttpClientErrorException erroOcorrido ) { //Se rolar algum problema com a requisicao

			//Imprimindo o erro ocorrido
			System.out.println("\n\nOcorreu um erro ao tentar fazer a requisicao: " +erroOcorrido);			

			/*
			 Esquema para adicionar objeto para caso for feito um redirecionamento de requisicao
			 Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
			----------------------------------->(chave de acesso, Objeto que quero vincular a pagina(view) ).
			*/
			model.addFlashAttribute("chaveMensagemDeFalha", "Valor maior que o permitido");
			
			//Retornando o objeto modelAndView como resposta da requisicao.
			return modelAndView;			
			
			
		}//catch
		
		
		
	}//finalizar

	

	
	
}//class


