package com.casadocodigo.loja.models;
import java.io.Serializable;
import java.math.BigDecimal;



public class CarrinhoItem implements Serializable{ //O " implements Serializable" eh so pelo fato de eu ter colocado um escopo nessa classe, caso contrario nao ia precisar.

	//Esse atributo nao serve para nada, mas eu preciso colocar ele aqui pq eu fiz o "implements Serializable". Eh uma regra nada ver, mas tem que fazer. Eu finjo que essa linha nem existe :)
	private static final long serialVersionUID = 1L;

	
	
	private Produto   produto;
	private TipoPreco tipoPreco;

	
	public CarrinhoItem( Produto produto, TipoPreco tipoPreco ) {
		
		this.produto   = produto;
		this.tipoPreco = tipoPreco;
	}


	//------Getters and Setters-----//
	
	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}


	
	public TipoPreco getTipoPreco() {
		return tipoPreco;
	}

	public void setTipoPreco(TipoPreco tipoPreco) {
		this.tipoPreco = tipoPreco;
	}


	//---------------------------------------------------------------//

	public BigDecimal getPreco(){
		
		return produto.precoPara(tipoPreco);
	}

	
	
	public BigDecimal getTotal(int quantidade) {
		
		
		return this.getPreco().multiply(new BigDecimal(quantidade));
	}
	
	
	
	//------------------------------------------------------//
	//Metodos sobreescritos para poder realizar comparacoes usando o metodo "containsKey()" la na classe  "CarrinhoCompras"

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((produto == null) ? 0 : produto.hashCode());
		result = prime * result + ((tipoPreco == null) ? 0 : tipoPreco.hashCode());
		return result;
	}


	//Esse metodo eh chamado pelo java quando preciso quando uso o metodo ".containsKey(exemplo)" de um objeto do tipo "Map<>" 
	//que estou usando dentro do metodo "getQuantidade()" da classe "CarrinhoCompras".
	@Override
	public boolean equals(Object obj) {
		
		if (this == obj) {
			return true;
		}
		
		
		if (obj == null) {
			return false;
		}
		
		
		if ( getClass() != obj.getClass() ){
			return false;
		}
		
		
		CarrinhoItem other = ( CarrinhoItem ) obj;
		if (produto == null) {
			
			if (other.produto != null)
				return false;
			
		} 
		else {
			if ( !produto.equals(other.produto) ){
			
				return false;
				}
		}
		
		
	
		if ( tipoPreco != other.tipoPreco ) {
			return false;
		}
		
		return true;
	}



	
	
	
	
}//class
