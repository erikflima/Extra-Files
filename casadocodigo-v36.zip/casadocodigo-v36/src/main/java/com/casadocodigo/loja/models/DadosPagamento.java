package com.casadocodigo.loja.models;
import java.math.BigDecimal;


public class DadosPagamento { 

	
	//OBS-> Esse atributo tem que que ter o nome de "value", pois pretendo enviar objetos "DadosPagamento" para um servico web
	//que estou fazendo na classe "PagamentoFinalController" dentro do metodo "finalizar()".
	private BigDecimal value;

	
	//Constructor 1
	public DadosPagamento(BigDecimal value) {
		
		this.value = value;
	}

	
	//Construtor Default. Estou declarando esse construtor aqui apenas como boa pratica.
	public DadosPagamento() {
	}
	
	//-----Getters and Setters------//
	public BigDecimal getValue() {
		
		return value;
	}
	
	
	
	
	
	
	
}//class
