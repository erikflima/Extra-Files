package com.casadocodigo.loja.models;
import java.math.BigDecimal;
import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;

/*Anotacao do JPA. A anotacao '@Embeddable' funciona juntamente com a anotacao "@ElementCollection". 
  Eu criei a classe "Preco" para ser um campo da classe "Produto". Ai como estou usando JPA. Quando a tabela "Preco" for criada, eu quero que ela nao tenha o campo "id"
  entao, para que isso funcione, eu tenho que colocar essa anotacao '@Embeddable' aqui na classe "Preco" e a anotacao "@ElementCollection" na classe "Produto"
 
  Mas na real, nem preciva disso. Foi so uma enrrolacao :(. Poderia ter feito do meu jeito mais fácil com a anotacao de relacionamento "OneToMany" e ja eras.
 */
@Embeddable
public class Preco {
	
	private BigDecimal valor;
	private TipoPreco  tipo; //Essa variavel so pode receber os valores definidos na classe "TipoPreco"

	
	//------------Getters and Setters-----------------//
	
	public BigDecimal getValor() {
		return valor;
	}
	
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	
	
	public TipoPreco getTipo() {
		return tipo;
	}
	public void setTipo(TipoPreco tipo) {
		this.tipo = tipo;
	}

	
}//class

