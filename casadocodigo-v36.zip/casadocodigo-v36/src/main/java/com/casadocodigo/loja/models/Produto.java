package com.casadocodigo.loja.models;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.springframework.format.annotation.DateTimeFormat;



@Entity  //Isso eh uma anotacao do Hibernate, no qual estou dizendo que essa classe reprenta um objeto de tabela do banco de dados
public class Produto {
	
	
	@Id                                               //Anotacao do Hibernate, no qual estou dizendo que o campo "id" eh o campo chave da tabela
	@GeneratedValue(strategy=GenerationType.IDENTITY) //Anotacao do Hibernate que diz que o campo "id" campo eh Auto-incrementado.E o "Strategy" eh pra dizer como que vai ser esse auto-incremento, que nesse caso vai ser de um em um.
	private Integer id;	
	
	private String titulo;
	
	private String descricao; 
	
	private int    paginas;
	
	                       
	@DateTimeFormat(pattern="yyyy-MM-dd") //Anotacao do Spring que defini qual o formato aceito. Ou seja, la no campo "Data de lancamento" da pagina "formulario.jsp", so vai ser aceito o preenchimento se digitar algo com o formato "yyyy-MM-dd", ex: 1989-10-25. Sem essa anotacao, vai ocorrer um erro de validacao, pois no arquivo "messages.proprities" eu deixei uma validacao para formatos digitados errados.
	private Calendar dataLancamento;
	
	
	/*Anotacao do JPA. Em teoria eu usuaria aqui uma anotacao "OneToMany", que criaria uma tabela no banco com o nome "Preco", e essa tabela teria o campo "id"
	  porem, eu nao quero que a tabela "Preco" tenha o campo "id", entao uso essa anotacao "@ElementCollection". 
	  Ou seja, essa anotacao faz o relacionamento entre a tabela "Produto" e "Preco", mas a tabela "Preco" nao vai ter campo "id". 
	  E para que isso funcione, a classe "Preco" tem que ter a anotacao "@Embeddable"  
	  
	    Mas na real, nem preciva disso. Foi so uma enrrolacao :(. Poderia ter feito do meu jeito mais fácil com a anotacao de relacionamento "OneToMany" e ja eras.
	  */
	@ElementCollection 
	private List<Preco> precos = new ArrayList<>();
	
	
	/* Campo para guardar o caminho do arquivo que o usuario fez upload */
	private String sumarioPath;
	
	
	
	//------------Getters and Setters-----------------//

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	//--

	public String getTitulo() {
		return titulo;
	}
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	//--
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	//--
	
	public int getPaginas() {
		return paginas;
	}
	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}

	//--
	public Calendar getDataLancamento() {
		return dataLancamento;
	}

	public void setDataLancamento(Calendar dataLancamento) {
		this.dataLancamento = dataLancamento;
	}	
	
	
	//--
	
	public List<Preco> getPrecos() {
		return precos;
	}

	public void setPrecos(List<Preco> precos){
		this.precos = precos;
	}
	
	//--
	
	public String getSumarioPath(){
		return sumarioPath;
	}

	public void setSumarioPath(String sumarioPath){
		this.sumarioPath = sumarioPath;
	}
	
	//------------------------------------------------------//	
	
	
	@Override
	public String toString() {
		
		return "Produto [titulo=" + titulo + ", descricao=" + descricao + ", paginas=" + paginas + "]";
	}


	
	public BigDecimal precoPara(TipoPreco tipoPreco) {
		
		//Expressao lambda do java
		return precos.stream().filter(preco -> preco.getTipo().equals(tipoPreco)).findFirst().get().getValor();
	}

	
	
	
	
	//------------------------------------------------------//		
	//Metodos sobreescritos para poder realizar comparacoes usando o metodo "containsKey()" la na classe  "CarrinhoCompras"
	
	@Override
	public int hashCode() {
		
		final int prime = 31;
		int   result = 1;
		
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		
		return result;
	}

	
	@Override //Aqui eu defino que a java vai realizar a comparacao de objetos do tipo "Produto" pelo atributo "id".
	public boolean equals(Object obj) {
		
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if ( getClass() != obj.getClass() ){
			return false;
	    }
		
		
		Produto other = (Produto) obj;
		if (id == null) {
		
			if (other.id != null)
				return false;
			
		} else {
			if ( !id.equals(other.id) ) {
				return false;
			}
		  }
		
		return true;
	}


	
	
	


}//class
