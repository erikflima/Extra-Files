package com.casadocodigo.loja.models;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.security.core.GrantedAuthority;



@Entity  //Isso eh uma anotacao do Hibernate, no qual estou dizendo que essa classe reprenta um objeto de tabela do banco de dados
public class Role implements GrantedAuthority{ //GrantedAuthority: Dizendo que essa classe vai ser uma classe que guarda permissoes. OBS: Nesse projeto, essa implementacao foi feita em ligacao com o metodo "getAuthorities()", da classe "Usuario".
	
	
	//Esse atributo nao serve para nada, mas eu preciso colocar ele aqui pq eu fiz o "implements GrantedAuthority". Eh uma regra nada ver, mas tem que fazer. Eu finjo que essa linha nem existe :)
	private static final long serialVersionUID = 1L;
	
	
	
	@Id //Anotacao do Hibernate, no qual estou dizendo que o campo "id" eh o campo chave da tabela
	private String nome;

	
	
	//-------------Getters and Setters--------------//
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	//-------Metodos obrigatorios por que vem da implementcao da interface "GrantedAuthority" ------//
	
	
	
	//Metodo chamado pelo Spring que retorna o nome da role(permissao)
	@Override
	public String getAuthority() {
		
		//Retornando o nome da permissao
		return this.nome;
	}
	
	
}//class
