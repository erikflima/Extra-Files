package com.casadocodigo.loja.validation;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.casadocodigo.loja.models.Produto;

/*Classe reponsavel por validar os dados digitados do formulario da pagina "form.jsp */


//implements Validator -> Digo ao Spring que essa vai ser uma classe de validacao.
public class ProdutoValidation implements Validator {
	

	/*
	 1°) Metodo chamado pelo Spring.
	    Esse metodo retorna para o Spring qual tipo de objeto essa clase vai validar. Que nesse caso, eu digo que essa classe
	    vai validar objetos do tipo "Produto". 
	    Se o objeto recebido realmente foi do tipo "Produto", entao o Spring chama o proximo metodo "validade()", caso contrario
	    um erro ocorrera. */
	@Override
	public boolean supports( Class<?> classe ) {
		
		//Retorno dizendo que essa classe so valida objetos do tipo "Produto".
		return Produto.class.isAssignableFrom( classe );
	}

	
	
	
	
	/*
	 2°) Metodo chamado pelo Spring.
	 	Realiza validacao do objeto do tipo "Produto" recebido do formulario da pagina "form.jsp. 
	 	
	 	Obs: 
	 	 target -> Eh o objeto recebido para validar.
	 	 errors -> Objeto do tipo Errors que o Spring me passou para auxiliar as validacoes.
	 	*/	
	@Override
	public void validate( Object target, Errors errors ) {

		
		//Transformando o objeto recebido em "produto"
		Produto produto = (Produto) target;
		
		/*
		  OBS: ValidationUtils eh uma classe do Spring que ajuda na validacao de objetos, pois tem alguns metodos auxiliares para validacao.
		  Ou seja, para validar os daddos, eu uso os metodos da classe ValidationUtils. 
		  Se ocorrer
		  */

		//Digo que o campo titulo do objeto "produto" nao de estar vazio.
		//-------------------------->( Objeto do tipo Errors que o Spring me passou, campo que quero validar do objeto, verificacao que quero fazer ); 
		ValidationUtils.rejectIfEmpty( errors, "titulo", "field.required" );

		
		
		//Digo que o campo descricao do objeto "produto" nao de estar vazio.
		//-------------------------->( Objeto do tipo Erros que o Spring me passou, campo que quero validar do objeto, verificacao que quero fazer );
		ValidationUtils.rejectIfEmpty( errors, "descricao", "field.required" );			
	
		
		//Digo que o campo "paginas" do objeto "produto" eh um campo obrigatorio e tambem nao deve ser menor ou igual a zero.
		if( produto.getPaginas() <= 0 ) {
			
			errors.rejectValue( "paginas", "field.required");
		}		
		

		//Digo que o campo dataLancamento do objeto "produto" nao de estar vazio.
		//-------------------------->( Objeto do tipo Erros que o Spring me passou, campo que quero validar do objeto, verificacao que quero fazer );
		ValidationUtils.rejectIfEmpty( errors, "dataLancamento", "field.required" );			
		
		
	}//validate

	
	
	
	
}//class
