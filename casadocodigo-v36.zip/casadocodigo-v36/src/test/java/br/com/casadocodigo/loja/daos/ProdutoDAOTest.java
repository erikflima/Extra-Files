package br.com.casadocodigo.loja.daos;
import java.math.BigDecimal;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.casadocodigo.loja.configuracao.JPAConfiguration;
import com.casadocodigo.loja.daos.ProdutoDAO;
import com.casadocodigo.loja.models.Produto;
import com.casadocodigo.loja.models.TipoPreco;
import br.com.casadocodigo.loja.builders.ProdutoBuilder;
import br.com.casadocodigo.loja.configuracao.DataSourceConfigurationTest;



//Essa eh uma classe que estou utilizando para testes

@RunWith(SpringJUnit4ClassRunner.class)                                                                       //Aqui eu uso a anotacao da biblioeca JUnit "@RunWith", e digo para o JUnit usar a classe "SpringJUnit4ClassRunner" da biblioteca "Spring-test". Se eu nao fizer isso, o teste nao vai funcionar. Fazendo isso, o objeto "produtoDAO" vai ser injetado sem problemas.
@ContextConfiguration(classes = {JPAConfiguration.class,ProdutoDAO.class,DataSourceConfigurationTest.class})  //Anotacao da biblioteca "spring-test" que diz onde estao os arquivos de configuracao que serao usados no teste.
@ActiveProfiles("banco_para_testes")                                                                          //Anotacao do Spring que diz que quero acessar o banco de daods "casadocodigo_test" que criei. Ai la na classe "DataSourceConfigurationTest", eu especifiquei o endereco e senha do banco.
public class ProdutoDAOTest{
	
		
	
	@Autowired   //Anotacao que faz o Spring injete(crie) um objeto do tipo ProdutoDAO. IMPORTANTE: Lembrando que so posso fazer injecao aqui nesse metodo de teste, pq coloquei a anotacao "@RunWith(SpringJUnit4ClassRunner.class)" e "@ContextConfiguration(classes = {JPAConfiguration.class,ProdutoDAO.class})"
	private ProdutoDAO produtoDAO;

	
	
	
	
	/*Metodo de teste para ver se o metodo "somaPrecosPorTipo()" da classe "ProdutoDAO" funciona corretamente. */
	@Test          //Anotacao do Junit, que diz que esse metodo vai realizar um teste, e quem vai rodar o teste vai ser o JUnit.
	@Transactional //Anotacao do Spring, que diz que esse metodo faz acesso a algum banco de dados.
	public void deveSomarTodosOsPrecosPorTipoLivro() {
		
		

		
		
		//Criando uma lista de objetos "Produtos" do tipo "IMPRESSO" para usar no teste da soma.
		//ProdutoBuilder eh so um objeto que criei que me retorna uma lista de objetos do tipo "Produto" para usar nesse teste.
		List<Produto> livrosImpressos = ProdutoBuilder.newProduto( TipoPreco.IMPRESSO, BigDecimal.TEN ).more(3).buildAll();
		
				
		//Criando uma lista de objetos "Produtos" do tipo "EBOOK" para usar no teste da soma.
		//ProdutoBuilder eh so um objeto que criei que me retorna uma lista de objetos do tipo "Produto" para usar nesse teste.				
		List<Produto> livrosEbook = ProdutoBuilder.newProduto(TipoPreco.EBOOK, BigDecimal.TEN).more(3).buildAll();
		
		
		/*Salvando os livros que criei no banco. 
		  Aqui eu estou utilizando o metodo "stream()" do Java 8. Ou seja, estou salvando todos os objetos da lista no banco 
		  
		  IMPORTANTE: SE ESTIVER GRAVANDO O BANCO DE TESTE, APOS EXECUTAR O TESTE, O BANCO VAI SER LIMPO, OU SEJA, NAO VAI FICAR NENHUMA LINHA.
		  */
		livrosImpressos.stream().forEach(produtoDAO::gravar);
		livrosEbook.stream().forEach(produtoDAO::gravar);
		
		
		
		
		
		/*Nessa linha eu de fato testo o metodo "somaPrecosPorTipo()" da classe "ProdutoDAO".
		  Quero testar se o retorna desse metodo vai ser realmente a soma dos valores do tipo de preco que estou passando.*/
		BigDecimal valorRetornado = produtoDAO.somaPrecosPorTipo(TipoPreco.EBOOK);
		
		
		//Aqui eu crio o valor que eu espero que o metodo de retorne. Claro, eh bom olhar no banco, fazer a soma, e pra saber que valor eu coloco aqui.
		//Obs; BigDecimal(40) -> Valor 40
		//Obs: setScale(2)    -> O valor vai ter 2 casas decimais
		BigDecimal valorQueEsperoReceber =  new BigDecimal(40).setScale(2);
		//BigDecimal valorQueEsperoReceber =  new BigDecimal(2426.00).setScale(2);
		
		
		//Usando o Framework de teste JUnit.
		//Aqui eu uso a classe "Assert" da biblioteca JUnit.
		//O metodo "assertEquals()" compara se os valores sao iguais.
		Assert.assertEquals(valorQueEsperoReceber, valorRetornado);

		
		
		
	}//deveSomarTodosOsPrecosPorTipoLivro
	
	
	
	
	
	
}//class
