package com.casadocodigo.loja.configuracao;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.guava.GuavaCacheManager;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mail.MailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import com.google.common.cache.*;




@EnableWebMvc  //Habilita o uso do Spring MVC dentro do projeto                                         
@EnableCaching //Habilta o Spring a trabalhar com cache a aplicação.
@ComponentScan(basePackages={"com.casadocodigo.loja.controllers","com.casadocodigo.loja.daos","com.casadocodigo.loja.infra","com.casadocodigo.loja.models"}) /*Aqui eu devo dizer os pacotes que estao alguns itens que o Spring deve encontrar:
                                                                                                                               - Dizer em qual pacote vao ficar os Controllers do projeto -> "com.casadocodigo.loja.controllers"
                                                                                                                               - Dizer em qual pacote vao ficar os Daos do projeto        -> "com.casadocodigo.loja.daos" 
                                                                                                                               - Dizer em qual pacote esta a classe "FileSaver" que criei para auxiliar no processo de salvar no servidor arquivos enviados pelo usuario -> "com.casadocodigo.loja.infra" 
                                                                                                                               - Dizer em qual pacote esta a classe "CarrinhoCompras", pois essa classe tem a anotacao @Component do Spring. ->"com.casadocodigo.loja.models"
                                                                                                                               */

public class AppWebConfiguration extends WebMvcConfigurerAdapter{ //So estou extendendo a classe WebMvcConfigurerAdapter para poder usar o metodo configureDefaultServletHandling() que esta um pouco mais abaixo. Deixei comentarios la.

	
	      
	@Bean                                                                //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public InternalResourceViewResolver internalResourceViewResolver() { //Esse metodo eh executado pelo Spring apartir da classe "ServletSpringMVC" que criei
		
		//Criando um obj do tipo "InternalResourceViewResolver", que eh responsavel por guardar algumas configuracoes que faco.
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		
		//Digo que as minhas paginas do projeto vao estar dentro da pasta "/WEB-INF/views/"
		resolver.setPrefix("/WEB-INF/views/");
		
		
		//Dizendo que o sufixo ".jsp" nao precisa ser digitado pelo usuario na url de requisicao
		//Ou seja, ao inves de digitar "casadocdigo/pagina1.jsp", basta digita "casadocodigo/pagina1"
		//Lembrando que eu so faco isso pq todas as paginas desse projeto vao ser ".jsp"	
	    resolver.setSuffix(".jsp");
		
	    
	    /*Isso permite que a classe as classes que coloquei a anotacao "@Component" do Spring, terao uma instancia e  ficaram disponiveis para ser acessadas nas paginas JSP.*/
	    //resolver.setExposeContextBeansAsAttributes(true);

	    /*Isso permite que a classe "CarrinhoCompras" que coloquei a anotacao "@Component" do Spring, tera uma instancia e ficara disponivel para ser acessadas nas paginas JSP, apartir do codigo ${carrinhoCompras.exemploDeAlgumaCoisa}*/
	    resolver.setExposedContextBeanNames("carrinhoCompras");
	    
		return resolver;
	}
	
	
	
	/* Esse metodo so eh chamado pelo Spring se eu estiver usando validacao de formulario.
	   Esse metodo retorna para o Spring onde esta o arquivo que criei "message.properties" que esta dentro da pasta "WEB-INF",
	   esse arquivo tem a lista de mensagens de erro das validacoes dos formularios do projeto.
	*/
	@Bean   //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public MessageSource messageSource(){

		//Objeto que serve para 
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		
		//Digo ond esta o arquivo que crie e contem as mensagens de erro.
		//messageSource.setBasename("/WEB-INF/messages"); 
		messageSource.setBasename("/WEB-INF/messages"); 
		
		//Digo qual o padrao de acentuacao que as mensagens de erro vao ter.
		messageSource.setDefaultEncoding("UTF-8");
		
		//Digo de quanto em quanto tempo o Spring verificar se esse arquivo foi atualizado se caso o arquivo for atualizado.
		//O padrao eh deixar 1 segundo
		messageSource.setCacheSeconds(1);
		
		//Retorna esse objeto para o Spring com as configuracoes que fiz.
		return messageSource;
		
		
		
	}//messageSource
	
	
	
	
	/* Esse metodo so eh chamado pelo Spring se eu estiver usando envio de arquivos atraves de formularios para serem armazenados no sevidor.
	   Metodo de implementacao obrigatoria se eu precisar fazer upload de arquivos para o servidor.
	*/	
	@Bean   //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public MultipartResolver multipartResolver(){
		
		
		StandardServletMultipartResolver standardServletMultipartResolver = new StandardServletMultipartResolver();
		
		//Retornando um objeto do tpo "StandardServletMultipartResolver" que eh filha de "MultipartResolver"
		return standardServletMultipartResolver;
		
	}
	
	
	
	
	/* Esse metodo so eh chamado pelo Spring se eu estiver injetando em algum lugar do projeto um objeto do tipo "RestTemplate". Que nesse projeto eu estou injetando la na classe "PagamentoFinalController"
	   Ai o Spring nao se perde e sabera como injetar objetos desse tipo ai.
	*/		
	@Bean //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public RestTemplate restTemplate(){
		
		
		//Criando um objeto do tipo "RestTemplate" do Spring, que serve para fazer requisicoes
		RestTemplate restTemplate = new RestTemplate();
		
		
		/*Aqui eu digo qual biblioteca de conversao de objetos para JSON eu vou usar. Que nesse caso eu digo que vou usar
		 a biblioteca "Jackson", pq eu ja tenho essa biblioteca adicionada como dependencia la no pom.xml
		 OBS: Achei essa diga la no StackOverFlow
		 */
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter() );
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter()          );
		
		return restTemplate;
	}
	
	
	
	
	
	
	/* Esse metodo so eh chamado pelo Spring se eu estiver usando cache na aplicacao.*/		
	@Bean //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public CacheManager cacheManager(){
		
		
		//Criando um objeto gerenciador de cache
		GuavaCacheManager manager = new GuavaCacheManager();

		
		
		//Usando um objeto CacheBuilder para guardar as configuracoes que o meu gerenciador de cache vai ter
		// maximumSize       -> Quantos elementos cache pode guardar
		// expireAfterAccess -> Em quanto tempo o cache vai expeirar
		CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder().maximumSize(100).expireAfterAccess(5, TimeUnit.MINUTES);
		
		
		//Passando as configuracoes para o gerenciador de cache
		manager.setCacheBuilder(builder);

		
		//Retorno um objeto gerenciador de cache para o Spring.
		return manager;

	}	
	
	

	/*
    Esse metodo serve para que o Spring saiba que eu criei a pasta "resources"(webapp -> resources) no projeto.
    Isso pq  estou usando arquivos CSS que estao vindo dessa pasta la nas paginas lista.jsp e formulario.jsp.
    Sim, eh so para isso mesmo. Na duvida eh melhor assistir o video -> Curso Spring MVC II Integração, cache, segurança e templates\3-Usando o Bootstrap
	*/
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		
		//Aqui eu digo para o Spring que coloquei a pasta "resources"(webapp -> resources) no projeto.
		configurer.enable();
		
	}
	
	
	
	
	
	
	
	/*Aqui eu digo para o Spring que quero usar "interceptadores".
	  Digo que quero ter um interceptador de locale, ou seja, de idioma de exibicao. 
	  Lembrado que esse metodo funciona juntamente com o metodo "localeResolver()"
	 */
	public void addInterceptors(InterceptorRegistry registry) { //O Spring me passa o objeto "registry"
		
	
		/*Aqui eu crio uma instancia de LocaleChangeInterceptor, que eh um objeto que o Spring usa para receber qual idioma de exibicao o usuario quer usar.
		  Eu coloquei botoes para o usuario selecionar o idioma de exibiao desejado no "cabecalho.jsp", e quando o usuario clicar em um dos botoes(EN ou PT), o parametro que diz qual idioma o usuaro escolheu, vai ser recebido por esse interceptador. */
		LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
		
		//Aqui eu digo que vou registrar um interceptador de locale, ou seja, de idioma de exibicao. E mando ele para o spring.
		registry.addInterceptor( localeChangeInterceptor );
		
    }//addInterceptors

	
	
	
    /*Esse metodo vai ser executado apos o metodo  "addInterceptors()".
      Esse metodo salva um cookie no navegador do usuario, e guarda o idioma que ele escolheu. Assim o usuario nao vai precisar clicar no botao de troca de idioma a cada pagina visitada.      */
	@Bean  //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	public LocaleResolver localeResolver(){
		
		
		//Criando uma instancia de CookieLocaleResolver, que eh o objeto que o Spring vai usar para salvar o cookie no navegador do usuario que diz qual idioma de exbicao ele quer usar.
		CookieLocaleResolver cookieLocaleResolver = new CookieLocaleResolver();
		
		//Passo o objeto para o Spring usar.
		return cookieLocaleResolver;
		
	} //localeResolver()

	
	
	
	/* Esse metodo so eh chamado pelo Spring quando eh necessario injetar algum objeto do tipo "MailSender"
	   Ai o Spring nao se perde e sabera como injetar objetos desse tipo ai.
	*/			
	@Bean
	public MailSender mailSender(){
		
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("smtp.gmail.com");
		mailSender.setUsername("alura.springmvc@gmail.com");
		mailSender.setPassword("alura2015");
		mailSender.setPort(587);
		
		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.auth", true);
		mailProperties.put("mail.smpt.starttls.enable", true);
		mailSender.setJavaMailProperties(mailProperties);
		
		return mailSender;
		
	}//mailSender()

	
	
	

}//class
