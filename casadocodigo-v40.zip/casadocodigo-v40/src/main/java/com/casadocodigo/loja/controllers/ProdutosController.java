package com.casadocodigo.loja.controllers;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.casadocodigo.loja.daos.ProdutoDAO;
import com.casadocodigo.loja.infra.FileSaver;
import com.casadocodigo.loja.models.Produto;
import com.casadocodigo.loja.models.TipoPreco;
import com.casadocodigo.loja.validation.ProdutoValidation;



@Controller                 //Anotacao que diz que essa classe vai ser um Controller do Spring (Ou seja, uma classe Servlet que recebe as requisições http)
@RequestMapping("/produtos") //Dizendo que todos os metodos desse controller vao ter a uri com inicio "http://localhost:8080/casadocodigo-v8/produtos"
public class ProdutosController {
	
	
	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo ProdutoDAO
	private ProdutoDAO produtoDao;

	
	@Autowired //Anotacao que faz o Spring injete(crie) um objeto do tipo FileSaver.
	private FileSaver fileSaver;	
	
	
	
	
	/*Dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v8/produtos", esse metodo sera responsavel por enviar uma resposta
    Tambem digo que esse metodo vai ser executado somente se a requisicao que o usuario fizer for do tipo "GET".
  */
	@RequestMapping(method=RequestMethod.GET) 
	public ModelAndView listar() {
		
		System.out.println("\n\nProdutosController - Executando o metodo 'listar()' ");
		
	
		
		//Pegando todos as linha da tabela "Produto" no db.
		List<Produto> listaDeProdutos = produtoDao.listar();
		
		

		//Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		//Defino para qual pagina vou retornar----->( nome pagina jsp que vou retornar como resposta da requisicao ).
		ModelAndView modelAndView = new ModelAndView( "produtos/lista" );
		
		
		//Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
		//------------------->(chave de acesso, Objeto que quero vincular a pagina(view) ).
		modelAndView.addObject("chaveProduto", listaDeProdutos);
		
		
		//Retornando o objeto modelAndView como resposta da requisicao.
		return modelAndView;
		
	}	
	
	
	
	
	
	
	
	/*
	@RequestMapping(method=RequestMethod.POST) ->  Anotacao dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v8/produtos", esse metodo sera responsavel por enviar uma resposta.
                                                   Tambem digo que esse metodo vai ser executado somente se a requisicao que o usuario fizer for do tipo "POST".

	 Obs: 
	  @Valid                                -> Anotacao do Spring que indica qual objeto vou querer validar.
	  Produto produto                       -> Objeto que recebi na Requisicao e que vou querer validar.
	  RedirectAttributes redirectAttributes -> Esse parametro eh enviado automaticamente pelo Spring, e eu so pego isso no paramtro do metodo se eu precisar. Referencia Curso: Curso Spring MVC I Criando aplicações web - Parte: 5-Redirect com Escopo de Flash-Video: 1
	  BindingResult result                  -> Esse eh um objeto enviado enviado e atualizado automaticamente pelo Spring, e diz se houve ou nao erro de validacao de algum campo do objeto que pedi para validar.
      MultipartFile                         -> Eh um tipo do Spring que armazena o arquivo no qual o usuario fez o upload pelo formulario
     @CacheEvict                            -> Anotacao do Spring que limpa um cache especifico quando esse metodo for executado, nesse caso pedi para limpar o cache "cachePaginaHomeJSP" que foi introduzido na classe "HomeController" dentro do metodo "retornaHome()". "value" eh o nome do cache e "allEntries=true" diz que deve ser apagado todo o conteudo do cache.
	*/
	@CacheEvict(value="cachePaginaHomeJSP", allEntries=true)
	@RequestMapping(method=RequestMethod.POST) 
	public ModelAndView grava( MultipartFile sumario, @Valid Produto produto, BindingResult result, RedirectAttributes redirectAttributes ) { 
		
		System.out.println("\n\nProdutosController - Executando o metodo 'grava()' ");

			
		/*
		 Verificando o resultado da validacao dos dados recebidos da pagina "form.jsp" 
		 Se ocorrer algum erro de validacao apontado nas classes validadoras, entao...
		*/
		if( result.hasErrors() ){
			

			System.out.println("\n\nA validação do formulário foi realizada pela classe 'ProdutoValidaton', e ocorreram erros de validação.");
			
						
			/*
			 Executa o metodo "retornaFormulario()". E junto passo os resultados da validacao que deu erro. Eh dificil de entender pq nao indico isso em nenhum lugar.
			 
			 Lembrando que esse metodo retorna um objeto do tipo "ModelAndView", entao o 
			 retorno do metodo que estou deve ser do tipo "ModelAndView" tambem.
			 E lembrando que estou passando o objeto "produto" por parametro, apenas pelo esquema de validacao, onde quero que os dados digitados no formulario permanecam na tela. Ou seja, para que o formulario nao fique com o campos vazios e o usuario tenha que digitar tudo denovo. 
			 
			  */
			return retornaFormulario( produto );
			
			
		}


	
		/*---------Etapa de salvar  arquivo recebido atraves do formulario-------------*/

		/*Usando o metodo do objeto fileSaver para salvar o arquivo em uma pasta dentro do servidor, e retornar o endereco que esse arquivo foi salvo
		---------------------------->( Nome do diretorio/pasta do meu projeto que quero salvar o arquivo, arquivo que quero salvar ) */
		String path = fileSaver.write("arquivos-sumario", sumario );
		
		//Passando para o produto o caminho do arquivo.
		produto.setSumarioPath(path);	
		
		
		
		System.out.println("-- Objeto do tipo Produto recebido na requisicao via POST que veio da pagina 'form.jsp ---" );
		System.out.println(produto);	//toString da classe "Produto"
		
		//Gravando o produto recebido na tabela do banco de dados
		produtoDao.gravar( produto );
		
		
		
		/*
		Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		Defino para qual pagina vou retornar----->( pagina que vou retornar como resposta da requisicao ).
		
		 "redirect:produtos" -> Redirecionando a requisicao. 
		  Ou seja, redireciona a requisicao para a uri "http://localhost:8080/casadocodigo-v8/produtos"  do tipo "GET"
		  que por conseguencia vai cair no metodo "listar()", que devolve a pagina "lista.jsp" 
		  Fazer o redirecionamento, evita que informações fiquem salvas na memoria do navegador, e assim o redirecionamento nao corre o risco de cair na uri "http://localhost:8080/casadocodigo-v8/produtos"  do tipo "POST"	*/	 
		ModelAndView modelAndView = new ModelAndView("redirect:produtos");
		
		
		String mensagemDeSucesso = "Produto cadastrado com sucesso!";
		
		/*
		 Esquema para adicionar objeto para caso for feito um redirecionamento de requisicao
		 Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
		----------------------------------->(chave de acesso, Objeto que quero vincular a pagina(view) ).
		*/
		redirectAttributes.addFlashAttribute("chaveMensagemDeSucesso", mensagemDeSucesso);
	
		
		//Retornando o objeto modelAndView como resposta da requisicao.
		return modelAndView;
	}
	
	
	
	            //Metodo chamado automaticamente pelo Spring se eu estiver usando validacao. Ou seja, se em algum lugar do codigo eu usar a anotacao "@Valid", entao o Spring vai chamar esse metodo.
	@InitBinder // Anotacao do Spring que diz que esse metodo vai ser chamado pelo Spring, e ai eu digo quais sao as minhas classes validadoras.
	public void initBinder( WebDataBinder binder ){
		
		/* Aqui eu uso o objeto do tipo "WebDataBinder" que o Spring me passou por parametro,
		  e entao digo que a classe "ProdutoValition" sera uma classe de validacao
		*/
		binder.addValidators( new ProdutoValidation() );
		
		
	}//initBinder

	

	
	
	@RequestMapping("/form")                                //Anotacao dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v8/produtos/form", esse metodo sera responsavel por enviar uma resposta
	public ModelAndView retornaFormulario(Produto produto) { // Estou recebendo um objeto do tipo "produto". Se a requisicao veio do usuario, entao o "produto" vai estar "null", mas esse objeto so vai vir preenchido se esse metodo foi chamado pelo metodo "grava()", pois significa que tenho que enviar a pagina "formulario.jsp" com os campos preenchidos com o que o usuario digitou anteriormente. Mas quem vai manter os campos preenchidos eh o Spring. Na duvida eh so assistir o video "Curso Spring MVC I Criando aplicações web\8-Formatação de datas"
		
		System.out.println("\n\nProdutosController - Executando o metodo 'retornaFormulario()' ");

		
		//Pegando a lista de valores possiveis que coloque na classe enum "TipoPreco". 
		//O metodo "TipoPreco.values()" me retorna um array de objetos "TipoPreco"
		TipoPreco[] arrayDeTipoPreco = TipoPreco.values();

		
		//Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		//Defino para qual pagina vou retornar----->( nome pagina jsp que vou retornar como resposta da requisicao )
		ModelAndView modelAndView = new ModelAndView( "produtos/formulario" );
		
		
		//Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
		//------------------->(chave de acesso, Objeto que quero vincular a pagina(view) )
		modelAndView.addObject("chaveTipo", arrayDeTipoPreco);
		
		
		//Retornando o objeto modelAndView como resposta da requisicao
		return modelAndView;	
		
	}	
	
	

	
	
	
	/*Dizendo que se o usuario enviar uma requisicao para "http://localhost:8080/casadocodigo-v11/produtos/detalhe", esse metodo sera responsavel por enviar uma resposta
    Tambem digo que esse metodo vai ser executado somente se a requisicao que o usuario fizer for do tipo "GET".
    
      @PathVariable("id") -> Serve para fazer o esquema de deixar a url amigavel, ou seja, fazer a uri que vai aparecer a barra de navegacao do usurio mais bonita.
      /{id}               -> Trabalha juntamente com a anotacao @PathVariable("id"). Meio zuado de explicar digitando, mas eh para url amigaveis.
    
      Integer id          -> Parametro recebido pelo metodo detalhe().
  */
	@RequestMapping("/detalhe/{id}") 
	public ModelAndView detalhe( @PathVariable("id") Integer id) {

		
		System.out.println("\n\nProdutosController - Executando o metodo 'detalhe()' ");
		
		
		//Buscado o produto selecionado na tela pelo id
		Produto produto = produtoDao.find(id);

		
		//Objeto do Spring que serve para responder as requisicoes com uma pagina(View) e tambem vincular objetos a ela.
		//Defino para qual pagina vou retornar----->( nome pagina jsp que vou retornar como resposta da requisicao )
		ModelAndView modelAndView = new ModelAndView( "produtos/detalhe" );

		//Adicionando um "objeto" a pagina que vou retornar. E tambem coloco uma "chave" para fazer o acesso dentro da pagina(view)
		//------------------->(chave de acesso, Objeto que quero vincular a pagina(view) )
		modelAndView.addObject("produto", produto);
		
		
		
		//Retornando o objeto modelAndView como resposta da requisicao
		return modelAndView;	
		
		
	}//detalhe	
	
	


	
	
	
	
	
	
	
	/*Dizendo que se o usuario enviar uma requisicao para http://localhost:8080/casadocodigo-v1/produtos/formatojson/6", esse metodo sera responsavel por enviar uma resposta.
      Executado somente se a requisicao que o usuario fizer for do tipo "GET".
      A resposta enviada sera em formato JSON.
    
    
      @PathVariable("id") -> Serve para fazer o esquema de deixar a url amigavel, ou seja, fazer a uri que vai aparecer a barra de navegacao do usurio mais bonita.
      /{id}               -> Trabalha juntamente com a anotacao @PathVariable("id"). Meio zuado de explicar digitando, mas eh para url amigaveis.
      Integer id          -> Parametro recebido pelo metodo retornaDetalheEmFormatoJson().
    */
	@ResponseBody  //Anotacao do Spring para que o retorno desse metodo seja convertido para Json. Lembrado que a biblioteca Jackson eh responsavel por realizar a convercao da resposta para formato JSON
	@RequestMapping("/formatojson/{id}") 
    public Produto retornaDetalheEmFormatoJson( @PathVariable("id") Integer id) {

		
		
		
	/* A declaracao do metodo poderia ter sido sem url amigavel, entao seria mais simples, assim:
	@ResponseBody
	@RequestMapping("/formatojson")
    public Produto retornaDetalheEmFormatoJson( Integer id) {		
	*/
		
		
		System.out.println("\n\nProdutosController - Executando o metodo 'detalheJson()' ");
		
		
		//Buscado o produto selecionado na tela pelo id
		Produto produto = produtoDao.find(id);

		
		//Retornando a resposta em formato JSON
		//Nesse momento o Spring procura alguma biblioteca de convercao de objetos que esteveja presente no projeto, que nesse caso temos a Biblioteca "Jackson" adicionada la no POM.xml. Entao o Spring usa esse biblioteca para converter a resposta em json.
		return produto;

		
	}//retornaDetalheEmFormatoJson		
	
	
	
	
	

}//class

