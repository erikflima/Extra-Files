package com.casadocodigo.loja.daos;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.casadocodigo.loja.models.Produto;
import com.casadocodigo.loja.models.TipoPreco;


@Transactional// Diz ao Spring que essa classe eh do tipo "Dao" e que os objetos estaciados dessa classe vao fazer transacoes com banco de dados.
@Repository   // Anotacao que permite o Spring o poder de injetar objetos do tipo "ProdutoDAO" em outras classes. Ou seja, isso permite que eu va em outra classe e injete uma instancia do tipo "ProdutoDAO", caso contrario vai dar erro. Blz, eh so uma regra.
public class ProdutoDAO {

	
	
	@PersistenceContext            //Anotacao que faz com que o Spring injete(crie e inicie) esse objeto.
	private EntityManager manager; //"EntityManager" eh um tipo de objeto que tem metodos para realizar as operacoes no banco. Essa classe eh do pacote "javax.persistence.EntityManager".
	
	
	
	public void gravar(Produto produto) {
		
		//Grava o produto recebido na tabela "produto" do db.
		manager.persist( produto );
	
	}//gravar



	
	public List<Produto> listar() {

		//Variavel auxiliar.
		List<Produto> produtos;
		
		// Seleciona todos as linhas da tabela "produto" do db.
		produtos = manager.createQuery("select p from Produto p", Produto.class ).getResultList();
		
		//Retorna a lista de produtos.
		return produtos;
		
	}//listar



	//Busca um produto pelo id e o retorna.
	public Produto find(Integer id) {
		
		/*
		Selecionando um produto pelo id recebido.
		Produto produto = manager.find(Produto.class, id);
		return produto; 
		
		*/
		//Por incrivel que pareca, essa query so traz uma linha com o id que recebido.
		return manager.createQuery("select distinct(p) from Produto p join fetch p.precos preco where p.id = :id", Produto.class).setParameter("id", id).getSingleResult();
		

	}
	
	
	
	
	
	
	/* Retorna a soma dos produtos de um tipo especifico */
	public BigDecimal somaPrecosPorTipo( TipoPreco tipoPrecoRecebido ){
		
		
		//Faca a soma de todos os produto do tipo que recebi
		TypedQuery<BigDecimal> query = manager.createQuery("select sum(preco.valor)  from Produto p      join  p.precos preco      where preco.tipo = :tipoPreco", BigDecimal.class);
        /*
           "select sum(preco.valor)  
            from Produto p     join  p.precos preco      
            where preco.tipo = :tipoPreco", BigDecimal.class)   
        */
		
		query.setParameter( "tipoPreco", tipoPrecoRecebido);

		return query.getSingleResult();
	}


	
	
	
	
}//class
