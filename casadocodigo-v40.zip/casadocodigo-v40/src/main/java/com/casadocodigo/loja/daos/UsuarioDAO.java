package com.casadocodigo.loja.daos;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import com.casadocodigo.loja.models.Usuario;





@Repository   // Anotacao que permite o Spring o poder de injetar objetos do tipo "ProdutoDAO" em outras classes. Ou seja, isso permite que eu va em outra classe e injete uma instancia do tipo "ProdutoDAO", caso contrario vai dar erro. Blz, eh so uma regra.
public class UsuarioDAO  implements UserDetailsService{ //UserDetailsService foi implementado para que o metodo "userDetailsService()" la na classe "SecurityConfiguration", possa receber um objeto do tipo "UsuarioDAO"
	
	
	
	@PersistenceContext            //Anotacao que faz com que o Spring injete(crie e inicie) esse objeto.
	private EntityManager manager; //"EntityManager" eh um tipo de objeto que tem metodos para realizar as operacoes no banco
	
	
	
	
	//Metodo chamado pelo Spring para verificar os dados inseridos na tela de login
	//Ou seja, quando alguem preencher o formulario de login e clicar no botao para logar, o Spring vai chamar esse metodo
	public Usuario loadUserByUsername(String email){  // "email" eh o que o usuario digitou la no formulario da tela
		
		
		//Selecionando o usuario no banco
		//----------------------------------------->("Selecione as linhas da tabela Usuario" do banco "casadocodigo" onde o campo "email" da tabela eh igual ao "email" que estou passando como parametro,  Digo que retorno desse select tem que ser do tipo "Usuario")
		List<Usuario> usuarios = manager.createQuery("select u from Usuario u where u.email = :email", Usuario.class)
		.setParameter("email", email).getResultList();
		


	
		//Se nao encontrar nenhum usuario
		if( usuarios.isEmpty() ){
			
			//Joga uma excessao se o usuario nao encontrado
			throw new UsernameNotFoundException("O usuário "+ email +" não foi encontrado");
		}
		else {
			
			//Retorna o primeiro item da lista de objetos do tipo  "Usuario".
			return usuarios.get(0);
		}

	}//loadUserByUsername
	
	
	
}//class
