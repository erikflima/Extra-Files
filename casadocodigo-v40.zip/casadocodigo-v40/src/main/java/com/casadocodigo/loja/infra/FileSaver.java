package com.casadocodigo.loja.infra;
import java.io.File;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;


@Component //Anotacao que do Spring, que diz para o Spring que essa classe sera um componente do Spring no qual ele pode acessar para obter informacoes. E tambem o Spring vai saber injetar esse objeto se eu precisar.
public class FileSaver {
	

	
	@Autowired // Anotacao do Spring para injetar um objeto do tipo "HttpServletRequest" pra mim. Lembrando que eu nao preciso me preocupar com os parametros que o construtor desse objeto pede, eu apenas peco para o Spring e ele cria tudo sozinho.
	private HttpServletRequest request;
	
	
	
	
    //Metodo reponsavel por criar e salvar o arquivo recebido em uma pasta no servidor
	//---------------->(Endereco do local que quero salvar o arquivo, o arquivo em si)
	public String write( String baseFolder, MultipartFile file) {
		
		System.out.println("\n----Classe FileSaver. Executando o metodo 'write()'");
		
		
		try {
			
			//Extraindo o caminho da pasta dentro do projeto no qual o arquivo sera salvo.
			String realPath = request.getServletContext().getRealPath("/" +baseFolder);
			
			
			/* Definindo o local que o arquivo sera salvo e o nome do arquivo */
			String path = realPath + "/" + file.getOriginalFilename();

				
			//Criando o arquivo e armazenando o arquivo no local que defini..
			file.transferTo( new File(path) );
			
			
			System.out.println("\n\n-----Sobre o arquivo-----");
			System.out.println("BaseFolder(nome da pasta em que arquivo foi salvo: " +baseFolder);
			System.out.println("RealPath                                         : " +realPath );			
			System.out.println("Nome original do arquivo                         : " +file.getOriginalFilename());			
			System.out.println("Path final                                       : " +path);			
			System.out.println("\n\n");				
			
			
			//Auxiliar
			String caminhoDoArquivoDentroDoProjeto = baseFolder + "/" + file.getOriginalFilename();
					
			//Retornando o endereco no qual o arquivo foi salvo.
			return caminhoDoArquivoDentroDoProjeto;
			
		} 
		catch ( IllegalStateException | IOException excecaoOcorrida ) {
			
			//Para a execucao gerando um erro.
			throw new RuntimeException( excecaoOcorrida );
			
		}//try-catch
		
	}//write()
	
}//class
