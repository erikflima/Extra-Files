package com.casadocodigo.loja.models;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;


@Component                                        //Anotacao que do Spring, que diz para o Spring que essa classe sera um componente do Spring no qual ele pode acessar para obter informacoes. E tambem o Spring vai saber injetar esse objeto se eu precisar
@Scope(value=WebApplicationContext.SCOPE_SESSION) //Anotacao do Spring que define o escopo(duracao) da estancia dessa classe. E escolhi o escopo de Sessao, ou seja, a instancia dessa classe vai durar durante toda a permanecia do usuario na aplicacao, a instancia vai durar ate o usuario sair da aplicacao fechando todas as janelas.
public class CarrinhoCompras  implements Serializable{ //O " implements Serializable" eh so pelo fato de eu ter colocado um escopo nessa classe, caso contrario nao ia precisar.
	
	//Esse atributo nao serve para nada, mas eu preciso colocar ele aqui pq eu fiz o "implements Serializable". Eh uma regra nada ver, mas tem que fazer. Eu finjo que essa linha nem existe :)
	private static final long serialVersionUID = 1L;
	
	
	// Objeto do tipo 'Map'-'HashMap' permite armazenar elementos com uma chave. Ai com essa chave eu posso realizar um get usado a chave especifica.
	//A chave vai ser um  item um objeto do tipo "CarrinhoItem", e o conteudo vai ser um "numero inteiro"
	private Map<CarrinhoItem, Integer> itens = new LinkedHashMap<CarrinhoItem, Integer>();
	

	
	//Retorna uma array de "CarrinhoItem"
	public Collection<CarrinhoItem> getItens() {
		
		
		//Extraindo do array "itens" somente as chaves das posicoes.
		//Ou seja, "itens" eh composto pela chave do tipo "CarrinhoItem" e o valor do tipo "Integer", e nesse caso estou estraindo somente a chave.
		Collection<CarrinhoItem> listaDeItensARetornar = itens.keySet();
		
		//Retornando uma lista de "CarrinhoItem"
		return listaDeItensARetornar;
		
		//Retorna um array com somente a chave das posicoes.
		//return itens.keySet();
		
		}




	public void add( CarrinhoItem item ) {
		
		//Adicionando no array
		//------>( chave, valor )
		itens.put( item, getQuantidade(item) + 1 );
		
	}//add





	public Integer getQuantidade( CarrinhoItem item ) {
		
		/*Aqui eu verifico se o array do tipo "Map<>" tem alguma posicao com a chave "item" em questao.
		mas para que o "metodo containsKey()" funcione, tive que implementar o metodo auxiliar  "equals()" na classe "CarrinhoItem" e "Produto". */
		if(  !itens.containsKey(item) ) {//Se o array itens nao tem o item em questao, entao...
			
			//Adicionando no array			
			//------>(chave, valor)
			itens.put( item, 0 );
			
		}//if
		
		//Retornando o conteudo do item, ou seja o retorno eh um valor inteiro.
		//------------->(chave)
		return itens.get(item);
		
		
	}//getQuantidade

	
	
	
	public int getQuantidade() {
		
		//Expressao lambda do Java8 que eu nao manjo, mas o retorno aqui vai ser o total de posicoes dentro do array itens
		return itens.values().stream().reduce(0, (proximo, acumulador) -> proximo + acumulador);

	}//
	

	
	public BigDecimal getTotal(CarrinhoItem item){
	
		return item.getTotal(getQuantidade(item));
	}


	
	public BigDecimal getTotal(){
		
		BigDecimal total = BigDecimal.ZERO;
	
		//Para cada item dentro do faca. OBS: O comando "itens.keySet()" extrai somente a "chave" da posicao, que eh um objeto do tipo "CarrinhoItem"
		for (CarrinhoItem item : itens.keySet()) {
		     
			 total = total.add( getTotal(item) );
		}
		
		return total;
	}




	public void remover(Integer produtoId, TipoPreco tipoPreco) {
		
		Produto produto = new Produto();
		
		produto.setId(produtoId);
		
		itens.remove( new CarrinhoItem(produto, tipoPreco) );
		
	}

	
	
	
}//class
