package com.casadocodigo.loja.models;

/*Essa eh uma classe especial, que serve para definir os possiveis valores de uma variavel*/
public enum TipoPreco {

	//Esses sao os possiveis valores para uma instancia desta classe
	EBOOK, IMPRESSO, COMBO;
	
}
