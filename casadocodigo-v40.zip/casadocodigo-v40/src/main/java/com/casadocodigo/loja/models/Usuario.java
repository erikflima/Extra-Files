package com.casadocodigo.loja.models;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;



@Entity  //Isso eh uma anotacao do Hibernate, no qual estou dizendo que essa classe reprenta um objeto de tabela do banco de dados
public class Usuario implements UserDetails{ //UserDetails foi implementado para que o metodo "loadUserByUsername()" la na classe "UsuarioDAO", retornar um objeto do tipo "Usuario"
	
	
	//Esse atributo nao serve para nada, mas eu preciso colocar ele aqui pq eu fiz o "implements UserDetails". Eh uma regra nada ver, mas tem que fazer. Eu finjo que essa linha nem existe :)
	private static final long serialVersionUID = 1L;

	
	
	@Id  //Anotacao do Hibernate, no qual estou dizendo que o campo "id" eh o campo chave da tabela
	private String email;
	
	private String nome;
	
	private String senha;
	
	                                  //Lista de para guardar as permissoes de acesso do usuario. OBS: Essa classe "Role" foi eu que criei, e significa "permissoes" 
                                      //@OneToMany                -> Anotacao do Hibernate, dizendo esse campo eh uma chave estrangeira de relacionamento "1 pra N", O relacionamento eh: "1 Usuario pode ter N Roles(permissoes de acesso)", e "1 Role(permissao) pode ser de 1 Usuario".
	@OneToMany(fetch=FetchType.EAGER) //"(fetch=FetchType.EAGER)' -> Eh pra dizer para hibernate que se eu fizer uma leitura do objeto "Usuario", tambem deve ser carregado os "roles" associados a ele. Ou seja, eh o contrario do carregamento "lazy".
	private List<Role> roles = new ArrayList<Role>();

	
	
	
	//-------------Getters and Setters--------------//
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	//---
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	//----
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	//----
	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}


	
	
	//-------------Metodos obrigatorios por que vem da implementcao da interface "UserDetailsService" --------------//

	
	
	//Metodo chamado pelo Spring para pegar as permissoes de acesso(que sao chamadas de roles") do usuario em questao
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		
		//Retornando a lista de permissoes. OBS: Lembrando que a classe "Roles" esta implementando a interface "GrantedAuthority", tornando assim possivel retornar esse objeto nesse metodo.
		return this.roles;
	}
	
	
	
	//Metodo chamado pelo Spring para pegar a senha do usuario em questao
	@Override
	public String getPassword() {
		
		return this.senha;
	}

	
	
	//Metodo chamado pelo Spring para retornar o "user" do usuario. Que no meu caso eu estou usando o campo "email".
	@Override
	public String getUsername() {
		
		return this.email;
	}

	
	
	//Metodo chamado pelo Spring para saber se a conta do usuario esta "expirada" ou "nao expirada"
	@Override
	public boolean isAccountNonExpired() {
		
		//False = "Expirada"
		//true  = "Nao expirada"
		return true;
	}

	
	
	//Metodo chamado pelo Spring para dizer se a conta do usuario esta "bloqueada" ou "nao bloqueada"
	@Override
	public boolean isAccountNonLocked() {

		
		//False = "boqueada"
		//true  = "Nao bloqueada"
		return true;
	}

	
	
	//Metodo chamado pelo Spring para dizer se a credenciais do usuario esta "expirada" ou "nao expirada"

	@Override
	public boolean isCredentialsNonExpired() {
		
		
		//False = "Expirada"
		//true  = "Nao Expirada"
		return true;
	}

	
	
	//Metodo chamado pelo Spring para dizer se a conta do usuario esta "habilitada" ou "nao habilitada"
	@Override
	public boolean isEnabled() {

		//False = "Expirada"
		//true  = "Nao Expirada"
		return true;
	}
	
	
	
	
	
}//class