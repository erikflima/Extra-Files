package br.com.casadocodigo.loja.configuracao;
import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;



//Classe responsavel pelas configuracoes do perfil (caminho do banco, user, senha driver, etc..)para acesso ao banco de dados "casadocodigo_test"
public class DataSourceConfigurationTest{

	@Bean                             //Anotacao que diz que esse eh um metodo de configuracao para o Spring
	@Profile("banco_para_testes")     //Aqui eu coloco o nome que quero dar para esse profile. Ai depois posso usar esse nome.
	public DataSource dataSource(){
		
		
		//Diz os dados de acesso ao banco - Propriedades JDBC
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		
		dataSource.setUsername("root");                                     //User do banco
		dataSource.setPassword("breaks");                                   //Senha do banco
		dataSource.setUrl("jdbc:mysql://localhost:3306/casadocodigo_test"); //Nome do banco do esquema que estou chamando de "casadocodigo_test"
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		
		//Retornar para o Spring um objeto com as configuracoes do banco que quero acessar.
		return dataSource;
	
	}

	
}//DataSourceConfigurationTest
