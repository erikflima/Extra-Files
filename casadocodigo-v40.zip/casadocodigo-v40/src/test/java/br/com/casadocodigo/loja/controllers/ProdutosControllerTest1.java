package br.com.casadocodigo.loja.controllers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import com.casadocodigo.loja.configuracao.AppWebConfiguration;
import com.casadocodigo.loja.configuracao.JPAConfiguration;
import br.com.casadocodigo.loja.configuracao.DataSourceConfigurationTest;



//Essa eh uma classe que estou utilizando para testes



@RunWith(SpringJUnit4ClassRunner.class)                                                                                 //Aqui eu uso a anotacao da biblioteca JUnit "@RunWith", e digo para o JUnit usar a classe "SpringJUnit4ClassRunner" da biblioteca "Spring-test". Se eu nao fizer isso, o teste nao vai funcionar, pois o JUnit sozinho nao sabe como injetar o objeto "EntityManager" dentro do objeto "produtoDAO" para esse teste. Fazendo essa anotação, o objeto "produtoDAO" vai ser injetado sem problemas.
@ContextConfiguration(classes = {JPAConfiguration.class, AppWebConfiguration.class, DataSourceConfigurationTest.class}) //Anotacao da biblioteca "spring-test" que digo onde estao as classes de configuracao que serao usados no teste./ "DataSourceConfigurationTest.class"-> Nessa classe tem a definição do profile com o nome "banco_para_testes" que criei./ "AppWebConfiguration.class"-> Nessa classe eu defino que o projeto uso o esquema MVC, e tambem defino em qual diretorio do projeto estao as paginas jsp do projeto. E como no metodo "deveRetornarParaHomeComOsLivros()" eu peço para verificar se o retorno de um get eh a pagina "home.jsp", entao preciso colocar declarar a classe "AppWebConfiguration.class" aqui.
@WebAppConfiguration                                                                                                    //Anotacao obrigatoria, pois usei a classe "AppWebConfiguration.class" dentro da anotacao "@ContextConfiguration". Sim, eh meio doido mesmo, mas foi o que entendi.
@ActiveProfiles("banco_para_testes")                                                                                    //Anotacao do Spring que diz que quero acessar o banco de daods "casadocodigo_test" que criei. Ai la na classe "DataSourceConfigurationTest", eu especifiquei o endereco, usuario e senha do banco.

public class ProdutosControllerTest1 {
	

	
	private MockMvc mockMvc; //Para que possamos fazer requisições sem o uso de um navegador, precisamos de um objeto capaz de simular este procedimento.
	                         //Estes objetos que simulam comportamentos são conhecidos como Mocks. E para a criação de um mock no Spring, precisaremos definir um contexto.
	                         //Entao crio um objeto da classe "MockMvc" da biblioteca "springframework.test", um objeto desse tipo ja tem metodo "GET", "POST", "DELETE", etc.

	
	@Autowired                         //Anotacao que faz o Spring injetar esse objeto.
	private WebApplicationContext wac; //Esse objeto so serve como um auxiliar, para criar um objeto do tipo "MockMvc". 
	
	
	
	@Before //Anotacao do JUnit que faz com que esse metodo seja executado antes do teste.
	public void setup(){
		
		//Para criar um objeto do tipo "MockMvc", preciso criar ele apartir do "MockMvcBuilders" e passar um objeto do tipo "WebApplicationContext".
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}

	
	
	
	/*
	  O objetivo desse teste é verificar se quando eu chamar a url "http://localhost:8080/casadocodigo-v1/" pelo navegador, 
	  o retorno será a pagina "home.jsp". 
	*/
	@Test
	public void deveRetornarParaHomeComOsLivros() throws Exception{

		/* Usando o objeto "mockMvc" para fazer um get para a uri "http://localhost:8080/casadocodigo-v1/" 
		  Digo que espero receber obrigatoriamente como retorno a pagina "home.jsp"
		  Digo que espero que a pagina "home.jsp" tenha obrigatoriamente dentro dela o atributo "produtos"
		*/
		mockMvc.perform( MockMvcRequestBuilders.get("/") )
		                    .andExpect( MockMvcResultMatchers.forwardedUrl("/WEB-INF/views/home.jsp") )	
		                    .andExpect( MockMvcResultMatchers.model().attributeExists("produtos")     );
	
	}//deveRetornarParaHomeComOsLivros
	
	
	public void mensagemFinal(){
		System.out.println("\nTeste Finalizado!");
	}
	
	

}//class
