package br.com.erik.loja.resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import br.com.erik.loja.dao.CarrinhoDAO;
import br.com.erik.loja.modelo.Carrinho;


//Servico
//Essa classe pega informacao no DB e retorna para o cliente


@Path("carrinhos")               //Toda a classe deve ter esse @Path, que diz qual eh a URI do servidor no qual quero pegar os dados
public class CarrinhoResource {
	
	
	
	
	
	@GET                                 //Digo que esse metodo deve ser acessado usando GET
	@Produces(MediaType.APPLICATION_XML) //Digo que qual eh  tipo do retorno,nesse caso XML
	public String busca(){               //Vai no banco e retorna o conteudo
		
		
		Carrinho carrinho = new CarrinhoDAO().busca(1l);
		
		
		//Retorna objeto do tipo "Carrinho" e o metodo "toXML()" converte ele em XML
		return carrinho.toXML();
		
	}//busca

	
	
	
	
	
	
}//class
