package br.com.erik.loja;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.junit.Test;

import junit.framework.Assert;


//Esse programa eh um teste usando a biblioteca "JUnit" para ver se consigo pegar o XMl do link "http://www.mocky.io/v2/52aaf5deee7ba8c70329fb7d"


public class ClienteTest {
	
	@Test
	public void testaSeAConexaoComOServidorFunciona(){
		
		
		
		//Criando um obj Client
		Client client = ClientBuilder.newClient();
		
		
		//Informo o target, ou seja de onde vou pegar os dados
		WebTarget target = client.target("http://www.mocky.io");
		
		//Informo a continuacao do target/link. E quando o retorno dentro da variavel "conteudoRetornado"
		String conteudoRetornado = target.path("/v2/52aaf5deee7ba8c70329fb7d").request().get( String.class );
		
		
		System.out.println(conteudoRetornado);
		
		//Verificando se o conteudo retornado "Contem" o texto "Rua Vergueiro 3185". Eh so um teste de checagem de conteudo
		Assert.assertTrue( conteudoRetornado.contains ("<rua>Rua Vergueiro 3185")  );
		
		
		
		
	}
	
	
}//class
