package br.com.erik.loja;
import java.io.IOException;
import java.net.URI;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;




public class Servidor {

	public static void main(String[] args) throws IOException {
		
		
		//Indico onde esta a classe "CarrinhoResource.java" que eh a classe que tem os servicos
		ResourceConfig config = new ResourceConfig().packages("br.com.erik.loja.resource");
		
		
		//Crio a URI do servidor que vou utilizar
		URI uri = URI.create( "http://localhost:8080/" );
		
		
		//Criando o servidor local usando a biblioteca "Grizzly"
		HttpServer server = GrizzlyHttpServerFactory.createHttpServer( uri, config );
		
		
		System.out.println("Servidor rodando");
		
		
		//Aguardar o botao enter para finalizar o servidor
		System.in.read();
		
		
		//Para o sevidor
		server.stop();
		
		
	}//main
	
	
	
	
}//class
