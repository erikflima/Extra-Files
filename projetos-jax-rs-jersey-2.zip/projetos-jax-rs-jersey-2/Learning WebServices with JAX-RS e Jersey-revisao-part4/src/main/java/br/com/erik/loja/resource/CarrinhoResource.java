package br.com.erik.loja.resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import br.com.erik.loja.dao.CarrinhoDAO;
import br.com.erik.loja.modelo.Carrinho;


//Servico
//Essa classe pega informacao no DB e retorna para o cliente


@Path("carrinhos")               //Toda a classe deve ter esse @Path, que diz qual eh a URI do servidor no qual quero pegar os dados
public class CarrinhoResource {
	
	
	
	
	@Path("{id}")                                           //Digo que o parametro que recebo vai ser parte da url que eu chamar. Ou seja, http://localhost:8080/carrinhos/1
	@GET                                                    //Digo que esse metodo deve ser acessado usando GET
	@Produces(MediaType.APPLICATION_XML)                    //Digo que qual eh  tipo do retorno, nesse caso XML               
    public String busca(@PathParam("id") long idRecebido) { //Digo que esse metodo recebe um "id" do tipo "long" que vai vir na requisicao
		
		
		
		//Busca um objeto do tipo Carrinho com o id "1l" no meu banco de dados em memoria
		Carrinho carrinho = new CarrinhoDAO().busca(idRecebido);
		
		
		//Converto o objeto do tipo "Carrinho" para XML, faco isso usando o metodo "toXML()".
		return carrinho.toXML();
		
	}//busca

	
	
	
	
	
	
}//class
