package br.com.erik.loja.dao;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import br.com.erik.loja.modelo.Carrinho;
import br.com.erik.loja.modelo.Produto;




public class CarrinhoDAO {
	
	
	//Criando um banco de dados na memoria
	private static Map<Long, Carrinho> bancoDadosEmMemoria = new HashMap<Long, Carrinho>();
	private static AtomicLong          contador            = new AtomicLong(1);
	
	
	
	//Adicionando itens dentro do Array Map de objetos do tipo "Carrinho"
	static {
		
			
		Carrinho carrinho1 = new Carrinho();
	
		Produto videogame = new Produto(6237, "Videogame 4"    , 4000, 1);
		Produto esporte   = new Produto(3467, "Jogo de esporte", 60,   2);
		
		carrinho1.adiciona(videogame);
		carrinho1.adiciona(esporte);			
		carrinho1.para("Rua Vergueiro 3185, 8 andar", "Sao Paulo")	;			
		carrinho1.setId(1l);
		
		//----
		
		Carrinho carrinho2 = new Carrinho();
		
		Produto guarda_roupa = new Produto(9929, "Guarda Roupas", 4000, 3);
		Produto geladeira    = new Produto(1122, "Geladeira X",   60,   4);
		
		carrinho2.adiciona(guarda_roupa);
		carrinho2.adiciona(geladeira);
		carrinho2.para("Broadway St, 9 floor", "Vancouver");
		carrinho2.setId(2l);
		
		
		
		//Adicionando um obj Carrinho com produtos dentro dele no banco de dados em memoria
		//-------------------->(id do carrinho no banco, obj do tipo "carrinho")
		bancoDadosEmMemoria.put(1l, carrinho1);
		bancoDadosEmMemoria.put(2l, carrinho2);	
		
	}//static
	
	
	
	//Pega um o obj do tipo "Carrinho" no banco e o retorna.
	public Carrinho busca( Long id ) {
		
		Carrinho carrinhoASerRetornado = bancoDadosEmMemoria.get( id );
		
		return carrinhoASerRetornado;
	}
	
	
	
	public void adiciona( Carrinho carrinho ) {
		
		//Cria um "id" para o obj do tipo "Carrinho" que sera adicionado no banco.
		long id = contador.incrementAndGet();
		
		//Coloca o "id" criado no carrinho.
		carrinho.setId(id);
		
		//Adiciona o obj no banco.
		bancoDadosEmMemoria.put(id, carrinho);
		
	}//adiciona
	
	

	public Carrinho remove(long id) {
		
		return bancoDadosEmMemoria.remove(id);
		
	}//remove
	

}//class
