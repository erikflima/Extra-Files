package br.com.erik.loja;
import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.thoughtworks.xstream.XStream;

import br.com.erik.loja.modelo.Carrinho;
import junit.framework.Assert;


//Esse programa eh um teste usando a biblioteca "JUnit" para ver se consigo acessar o servico que criei"

public class ClienteTest {
	

	
	//Objeto que vai ser o meu servidor para rodar com a biblioteca "Grizzly"
	private HttpServer server;



	
	
	@Before //Anotacao do JUnit  que faz com que esse metodo seja executado antes de rodar os testes
	public void startaServidor() {

		/*---------Criando um Servidor para rodar com a biblioteca "Grizzly "-----------*/
		
		//Indico onde esta a classe "CarrinhoResource.java" que eh a classe que tem os servicos
		ResourceConfig config = new ResourceConfig().packages("br.com.erik.loja.resource");
		
		
		//Crio a URI do servidor que vou utilizar. Ou seja, o servidor vai rodar nesse endereco
		URI uri = URI.create( "http://localhost:8080/" );
		
		
		server = GrizzlyHttpServerFactory.createHttpServer( uri, config );
		
		
		System.out.println("Servidor Grizzly rodando");
	}
	
	
	
	
	@Test  //Anotacao do JUnit
	public void testeQueBuscarUmCarrinhoTrazOCarrinhoEsperado(){
		
		
		//Criando um obj Client
		Client client = ClientBuilder.newClient();
		
		
		//Informo o target, ou seja de onde vou pegar os dados
		WebTarget target = client.target("http://localhost:8080");
		
		
		//target.path                    -> Informa qual a uri que quero acessar 
		//.request().get( String.class ) -> Faco de fato a conexao
		String conteudoRetornado = target.path("/carrinhos").request().get( String.class );
		
		System.out.println("\nConteudo retornado: \n\n" +conteudoRetornado);
		
		
		
		//Pegando o XML que foi retornardo e convertendo ele para um objeto do tipo "Carrinho".
		//A conversao eh feita pelo metodo "fromXML" da biblioteca "XStream"
		Carrinho carrinho = (Carrinho) new XStream().fromXML(conteudoRetornado);
		

		//Verificando se o conteudo retornado "Contem" o texto "Rua Vergueiro 3185". Eh so um teste de checagem de conteudo
		//Assert.assertTrue( conteudoRetornado.contains ("<rua>Rua Vergueiro 3185")  );
		
		
		//Verificando se o conteudo retornado "eh igual" o texto "Rua Vergueiro 3185". Eh so um teste de checagem de conteudo
		Assert.assertEquals("Rua Vergueiro 3185, 8 andar", carrinho.getRua());
	}
	
	
	
	
	
    @After //Anotacao do JUnit  que faz com que esse metodo seja executado apos de rodar os testes
    public void mataServidor() {
    	
		//Para o sevidor
		server.stop();
		
		
		System.out.println("\n\nParando o Servidor Grizzly");
    }
	
    
}//class
