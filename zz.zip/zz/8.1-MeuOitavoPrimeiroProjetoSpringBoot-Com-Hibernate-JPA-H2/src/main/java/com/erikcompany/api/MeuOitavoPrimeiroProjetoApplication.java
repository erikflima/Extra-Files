package com.erikcompany.api;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import com.erikcompany.api.entities.Empresa;
import com.erikcompany.api.repositories.EmpresaRepository;

//Classe principal que de fato executa o projeto.


@SpringBootApplication //Anotacao do Spring Boot que faz tudo acontecer. Inicializa o Spring Boot, componentes, entre outras coisas.
public class MeuOitavoPrimeiroProjetoApplication {
	
	
	@Autowired //Anotacao do Spring que injeta o objeto. Eu literalmente nao preciso fazer nada, o spring faz tudo e posso usar os metodos do objeto criado.
	private EmpresaRepository empresaRepository;

	
	
	public static void main(String[] args) {
		
		System.out.println("\n\nErik - Executando o metodo main e apos isso o metodo SpringApplication.run, que roda a aplicacao literalmente!\n\n");
		
		SpringApplication.run(MeuOitavoPrimeiroProjetoApplication.class, args);
		
		System.out.println("\n\nErik - Finalizando a execucao do metodo main \n\n");	
	}

	
	
	
	@Bean  //Esse metodo eh um utilitario que eh executado toda vez que o metodo "SpringApplication.run()" roda.
	public CommandLineRunner commandLineRunner() {
		
		//Expressoa lambda maluca
		return args -> {
			
			System.out.println("\nErik - Executando o metodo 'commandLineRunner()' \n\n");	
			
			//Criando um objeto empresa para inserir no banco H2 que esta em memoria
			Empresa empresa1 = new Empresa();
			empresa1.setRazaoSocial("Erik IT in Canada");
			empresa1.setCnpj("11111111111111");
			                  
			Empresa empresa2 = new Empresa();
			empresa2.setRazaoSocial("Erik IT in USA");
			empresa2.setCnpj("22222222222222");
			                 
			
			                                       //INSERT
			                                       //Nesse momento o Spring vai utilizar o H2. Vai criar um banco, vai criar a tabela "EMPRESA" e vai inserir no banco. Tudo sozinho! Nao fiz nada!
			this.empresaRepository.save(empresa1); //Insert no banco de dados. Ou update se o objeto a ser salvo ja existir no banco.
			this.empresaRepository.save(empresa2); //Insert no banco de dados. Ou update se o objeto a ser salvo ja existir no banco.
			System.out.println("\nInsert realizado.\n\n");

			                                                                                         //SELECT
			Empresa empresaCnpjSelecionadaPeloCnpj = empresaRepository.findByCnpj("11111111111111"); //Selecionando por CNPJ no banco.
			System.out.println("\nSelect pelo CNPJ realizado.\n");
			System.out.println("Empresa encontrada pelo CNPJ: " + empresaCnpjSelecionadaPeloCnpj.toString() );
			
			
																				   //SELECT		
			Empresa empresaCnpjSelecionadaPeloId = empresaRepository.findOne(2L);  //Selecionando por ID no banco.
			System.out.println("\nSelect pelo Id realizado.\n");
			System.out.println("Empresa encontrada pelo Id : " + empresaCnpjSelecionadaPeloId.toString() );			
			
			
			                                                                     //UPDATE
			empresaCnpjSelecionadaPeloId.setRazaoSocial("Erik IT in Australia"); //Alteracao de campo 
			this.empresaRepository.save( empresaCnpjSelecionadaPeloId );         //Fazer o update no banco de dados. Ou insert se o objeto a ser salvo nao existir no banco.			
			System.out.println("\nUpdate realizado.\n");
			
			                                                                  //SELECT ALL
			List<Empresa> todasEmpresasDoBanco = empresaRepository.findAll(); //Seleciona todas as empresas da tabela.
			System.out.println("\nSelect All realizado.\n");
			for(Empresa aux : todasEmpresasDoBanco ){
				aux.toString(); 
			}
			
		                                       //DELETE
			this.empresaRepository.delete(1L); //Deletando da tabela a linha com id = 1.
			System.out.println("\nDelete realizado.\n");
			

			                                                           //METODO CRIADO E DEFINIDO POR MIM MESMO.
			int total = empresaRepository.pegaTotalDeLinhasDaTabela(); //Acessando o metodo que eu criei.
			System.out.println("\n\nMetodo que criei que faz um count: " +total+ "\n\n");
			
			
			System.out.println("\nErik - Finalizando o metodo 'commandLineRunner()' \n\n");
			
		};
	}
}