package com.erikcompany.api.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erikcompany.api.entities.Empresa;
import com.erikcompany.api.repositories.EmpresaRepository;


@RestController           //Anotacao do Spring que torna essa classe um endpoint.
@RequestMapping("/api")   //Anotacao do Spring que uso para definir qual sera o caminho do endpoint.
public class ExemploController {

	
	
	@Autowired //Anotacao do Spring que injeta o objeto. Eu literalmente nao preciso fazer nada, o spring faz tudo e posso usar os metodos do objeto criado.
	private EmpresaRepository empresaRepository;	

	
	
	                                   //@GetMapping  -> Anotacao do Spring que defino qual verbo quero utilizar. Poderia ser "@PostMapping" or "@DeleteMapping" or "@PutMapping" or "@PatchMapping".
	@GetMapping(value = "/selecionaTudo") 
	public ResponseEntity< List<Empresa> > selecionarTudo() {
		
		
		//SELECT ALL
		List<Empresa> todasEmpresasDoBanco = empresaRepository.findAll(); //Seleciona todas as empresas da tabela.
		
		System.out.println("\nSelect All realizado.\n");
		
		/*Aqui eu retorno uma instancia da classe "ResponseEntity". O metodo ok(), ja deixa esse objeto com status code +200-Ok.
		 Esse objeto ja tem um monte de atributos que uma resposta de servico tem, como por exemplo o campo "statusCode".
		 Entao eu uso esse objeto como reposta.
		*/
		return ResponseEntity.ok().body( todasEmpresasDoBanco );
	}



}